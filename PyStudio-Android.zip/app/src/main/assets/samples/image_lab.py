"""Image processing demo — use the file button next to Run to insert your own path."""
import cv2
import numpy as np

# Replace this generated image with a picked file, e.g.
# cv2.imread("/data/user/0/ir.pystudio.app/files/workspace/imports/photo.jpg")
height, width = 540, 960
image = np.zeros((height, width, 3), dtype=np.uint8)

for y in range(height):
    t = y / max(height - 1, 1)
    image[y, :] = (
        int(28 + 120 * t),
        int(54 + 150 * (1 - t)),
        int(40 + 90 * t),
    )

cv2.circle(image, (300, 270), 150, (155, 229, 100), -1)
cv2.circle(image, (620, 250), 105, (246, 200, 95), -1)
cv2.putText(image, "PyStudio x OpenCV", (210, 480), cv2.FONT_HERSHEY_SIMPLEX, 1.1, (10, 18, 12), 3)

gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
edges = cv2.Canny(gray, 60, 150)
print("Image shape:", image.shape)
print(f"Mean brightness: {gray.mean():.1f}")
print("Edge pixels:", int((edges > 0).sum()))

cv2.imshow("PyStudio - original", image)
cv2.waitKey(0)
cv2.destroyAllWindows()
