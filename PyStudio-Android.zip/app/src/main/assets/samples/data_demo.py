"""pandas + a compact terminal-friendly report."""
import pandas as pd
import numpy as np

rng = np.random.default_rng(21)
days = pd.date_range("2026-01-01", periods=14, freq="D")
frame = pd.DataFrame({
    "day": days,
    "runs": rng.integers(2, 18, size=14),
    "minutes": rng.integers(10, 95, size=14),
})
frame["per_run"] = (frame["minutes"] / frame["runs"]).round(1)

print("PyStudio usage — last 14 days")
print(frame.tail(7).to_string(index=False))
print("\nTotal minutes:", int(frame["minutes"].sum()))
print("Busiest day:", frame.loc[frame["minutes"].idxmax(), "day"].date())
