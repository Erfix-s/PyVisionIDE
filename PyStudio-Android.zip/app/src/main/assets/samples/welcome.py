"""PyStudio quick tour: run this file with the ▶ button."""
import numpy as np
import matplotlib.pyplot as plt

print("Hello from PyStudio on Android!")
print("Python + NumPy + Matplotlib are running entirely on your phone.\n")

signal = np.linspace(0, 2 * np.pi, 600)
wave = np.sin(signal) * np.exp(-signal / 5)
noise = np.random.default_rng(7).normal(0, 0.035, signal.size)

print(f"Samples: {wave.size}")
print(f"Peak amplitude: {np.abs(wave).max():.3f}")
print(f"Mean (should be ~0.12): {wave.mean():.3f}")

fig, ax = plt.subplots(figsize=(7, 3.6))
fig.patch.set_facecolor("#0f1311")
ax.set_facecolor("#111814")
ax.plot(signal, wave + noise, color="#9be564", linewidth=1.6, label="signal")
ax.plot(signal, wave, color="#f6c85f", linewidth=2, linestyle="--", label="clean")
ax.set_title("Damped wave · rendered in PyStudio", color="#e9f0ea", loc="left")
ax.tick_params(colors="#9aab9f")
for spine in ax.spines.values():
    spine.set_color("#2a352d")
ax.grid(color="#2a352d", alpha=0.45, linewidth=0.7)
ax.legend(facecolor="#151b17", labelcolor="#e9f0ea", edgecolor="#2a352d")

# plt.show() is captured by PyStudio and appears as an image in the Output tab.
plt.show()
