package ir.pystudio.app.python

import com.chaquo.python.Python
import java.io.File

/**
 * Methods must stay public and keep their names: pystudio_runtime.py calls them
 * directly on the Java object bridge.
 */
class PythonBridge(
    private val onStream: (String, Boolean) -> Unit,
    private val onImage: (String) -> Unit,
    private val cancellationRequested: () -> Boolean
) {
    fun write(text: String) = onStream(text, false)
    fun error(text: String) = onStream(text, true)
    fun image(path: String) = onImage(path)
    fun isCancelled(): Boolean = cancellationRequested()
}

class PythonRunner(private val workspace: File) {

    fun run(source: String, bridge: PythonBridge) {
        check(Python.isStarted()) { "Python runtime is not started" }
        workspace.mkdirs()
        Python.getInstance()
            .getModule("pystudio_runtime")
            .callAttr("run", source, workspace.absolutePath, bridge)
    }

    /** Imports heavy packages off the UI thread and returns JSON versions. */
    fun versions(): String {
        check(Python.isStarted()) { "Python runtime is not started" }
        return Python.getInstance()
            .getModule("pystudio_runtime")
            .callAttr("versions")
            .toString()
    }
}
