package ir.pystudio.app.data

import java.io.File

enum class OutputStream { STDOUT, STDERR, SYSTEM }

sealed interface OutputItem {
    data class Text(val text: String, val stream: OutputStream = OutputStream.STDOUT) : OutputItem
    data class Image(val path: String, val label: String) : OutputItem
    data class Note(val text: String) : OutputItem
}

enum class TerminalKind { INPUT, OUTPUT, ERROR, INFO }

data class TerminalEntry(val text: String, val kind: TerminalKind)

data class PythonLibrary(
    val name: String,
    val importName: String,
    val description: String,
    val badge: String,
    val tone: LibraryTone
)

enum class LibraryTone { GREEN, AMBER, BLUE, CORAL }

enum class StudioTab(val label: String) {
    EDITOR("Editor"),
    OUTPUT("Output"),
    TERMINAL("Terminal"),
    LIBRARIES("Libraries")
}

data class WorkspaceEntry(val file: File, val relativePath: String)

val BundledLibraries = listOf(
    PythonLibrary("NumPy", "numpy", "N-dimensional arrays, linear algebra and fast numeric kernels.", "C extension", LibraryTone.BLUE),
    PythonLibrary("OpenCV", "cv2", "Image processing, video frames and computer vision algorithms.", "Native", LibraryTone.GREEN),
    PythonLibrary("Matplotlib", "matplotlib", "Publication-quality plots. plt.show() renders in Output.", "Native", LibraryTone.AMBER),
    PythonLibrary("Pillow", "PIL", "Open, transform and save images. Image.show() renders in Output.", "Native", LibraryTone.CORAL),
    PythonLibrary("pandas", "pandas", "DataFrames, CSV/JSON pipelines and exploratory analysis.", "Native", LibraryTone.BLUE),
    PythonLibrary("Requests", "requests", "HTTP requests with a friendly, batteries-included API.", "Pure Python", LibraryTone.GREEN)
)
