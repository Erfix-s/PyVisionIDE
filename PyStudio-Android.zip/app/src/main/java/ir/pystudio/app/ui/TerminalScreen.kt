package ir.pystudio.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowUpward
import androidx.compose.material.icons.rounded.DeleteSweep
import androidx.compose.material.icons.rounded.Send
import androidx.compose.material.icons.rounded.Terminal
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ir.pystudio.app.StudioViewModel
import ir.pystudio.app.data.TerminalKind
import ir.pystudio.app.ui.theme.Amber
import ir.pystudio.app.ui.theme.BorderSoft
import ir.pystudio.app.ui.theme.Coral
import ir.pystudio.app.ui.theme.Ink
import ir.pystudio.app.ui.theme.Lime
import ir.pystudio.app.ui.theme.Surface
import ir.pystudio.app.ui.theme.SurfaceHigh
import ir.pystudio.app.ui.theme.SurfaceRaised
import ir.pystudio.app.ui.theme.TextFaint
import ir.pystudio.app.ui.theme.TextPrimary
import ir.pystudio.app.ui.theme.TextSecondary

@Composable
fun TerminalScreen(vm: StudioViewModel) {
    val listState = rememberLazyListState()
    var command by remember { mutableStateOf("") }
    val history = remember { mutableStateListOf<String>() }
    var historyIndex by remember { mutableStateOf(-1) }

    fun submit() {
        val value = command
        if (value.isNotBlank()) {
            history.add(0, value)
            historyIndex = -1
        }
        vm.submitShell(value)
        command = ""
    }

    LaunchedEffect(vm.terminalEntries.size) {
        if (vm.terminalEntries.isNotEmpty()) {
            runCatching { listState.animateScrollToItem(vm.terminalEntries.lastIndex) }
        }
    }

    Column(Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier.fillMaxWidth().background(Surface).padding(start = 14.dp, end = 5.dp, top = 11.dp, bottom = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Shell", color = TextPrimary, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.width(8.dp))
                    Surface(color = SurfaceRaised, shape = RoundedCornerShape(4.dp)) {
                        Text(
                            "sh",
                            color = Lime,
                            fontSize = 8.5.sp,
                            fontFamily = FontFamily.Monospace,
                            modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                        )
                    }
                }
                Text(vm.cwd.ifBlank { "/workspace" }, color = TextFaint, fontSize = 9.5.sp, fontFamily = FontFamily.Monospace)
            }
            IconButton(onClick = vm::clearTerminal) {
                Icon(Icons.Rounded.DeleteSweep, "Clear shell", tint = TextSecondary, modifier = Modifier.size(19.dp))
            }
        }
        Box(Modifier.fillMaxWidth().height(1.dp).background(BorderSoft))

        LazyColumn(
            state = listState,
            modifier = Modifier.weight(1f).fillMaxWidth().background(Ink),
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(3.dp)
        ) {
            items(vm.terminalEntries) { entry ->
                val color = when (entry.kind) {
                    TerminalKind.INPUT -> TextPrimary
                    TerminalKind.OUTPUT -> Color(0xFFC7D4C9)
                    TerminalKind.ERROR -> Coral
                    TerminalKind.INFO -> TextFaint
                }
                Row(verticalAlignment = Alignment.Top) {
                    if (entry.kind == TerminalKind.INPUT) {
                        Text("❯ ", color = Lime, fontFamily = FontFamily.Monospace, fontSize = 11.5.sp)
                    }
                    Text(
                        entry.text,
                        color = color,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.5.sp,
                        lineHeight = 17.sp,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .background(Surface)
                .padding(horizontal = 10.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            listOf("ls", "pip list", "python welcome.py", "help", "clear").forEach { quick ->
                Surface(
                    color = SurfaceRaised,
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.clip(RoundedCornerShape(6.dp)).clickable {
                        if (quick == "clear") vm.clearTerminal() else vm.submitShell(quick)
                    }
                ) {
                    Text(
                        quick,
                        color = TextSecondary,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 9.5.sp,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp)
                    )
                }
            }
        }

        Surface(color = SurfaceHigh, modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier.padding(start = 12.dp, end = 6.dp, top = 8.dp, bottom = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Rounded.Terminal, null, tint = Lime, modifier = Modifier.size(15.dp))
                Spacer(Modifier.width(7.dp))
                BasicTextField(
                    value = command,
                    onValueChange = { command = it },
                    modifier = Modifier.weight(1f),
                    singleLine = true,
                    textStyle = TextStyle(
                        color = TextPrimary,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 12.sp
                    ),
                    cursorBrush = SolidColor(Lime),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                    keyboardActions = KeyboardActions(onSend = { submit() }),
                    decorationBox = { inner ->
                        Box {
                            if (command.isEmpty()) {
                                Text(
                                    "Type a Linux-style command…",
                                    color = TextFaint,
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 11.sp
                                )
                            }
                            inner()
                        }
                    }
                )
                IconButton(
                    onClick = {
                        if (history.isNotEmpty()) {
                            historyIndex = (historyIndex + 1).coerceAtMost(history.lastIndex)
                            command = history[historyIndex]
                        }
                    },
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(Icons.Rounded.ArrowUpward, "Previous command", tint = TextFaint, modifier = Modifier.size(15.dp))
                }
                IconButton(onClick = { submit() }, modifier = Modifier.size(36.dp)) {
                    Box(
                        Modifier.size(30.dp).clip(CircleShape).background(Lime),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Rounded.Send, "Run command", tint = Color(0xFF0B1507), modifier = Modifier.size(15.dp))
                    }
                }
            }
        }
    }
}
