package ir.pystudio.app.data

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import java.io.File
import java.io.IOException

/**
 * The Python-visible workspace lives in app-private storage. Files chosen through
 * Android's Storage Access Framework are copied here so native libraries always
 * receive a real filesystem path (SAF does not expose one).
 */
class WorkspaceRepository(private val context: Context) {

    val root: File = File(context.filesDir, "workspace").apply { mkdirs() }
    val importsDir: File = File(root, "imports").apply { mkdirs() }
    val outputDir: File = File(root, ".pystudio_output").apply { mkdirs() }

    init {
        seedIfMissing()
    }

    private fun seedIfMissing() {
        val samples = listOf("welcome.py", "image_lab.py", "data_demo.py")
        samples.forEach { name ->
            val target = File(root, name)
            if (!target.exists()) {
                runCatching {
                    context.assets.open("samples/$name").use { input ->
                        target.outputStream().use { output -> input.copyTo(output) }
                    }
                }
            }
        }
    }

    fun list(relative: String = ""): List<WorkspaceEntry> {
        val directory = safeResolve(relative)
        if (!directory.isDirectory) return emptyList()
        return directory.listFiles()
            ?.filterNot { it.name == ".pystudio_output" }
            ?.sortedWith(compareBy<File>({ !it.isDirectory }, { it.name.lowercase() }))
            ?.map { WorkspaceEntry(it, relativePath(it)) }
            ?: emptyList()
    }

    fun read(relative: String, maxBytes: Int = 2_000_000): String {
        val file = safeResolve(relative)
        if (!file.isFile) throw IOException("File not found: $relative")
        if (file.length() > maxBytes) throw IOException("File is too large to open (${file.length()} bytes)")
        return file.readText()
    }

    fun write(relative: String, content: String): File {
        val file = safeResolve(relative)
        file.parentFile?.mkdirs()
        file.writeText(content)
        return file
    }

    fun mkdir(relative: String): File = safeResolve(relative).apply { mkdirs() }

    fun delete(relative: String): Boolean = safeResolve(relative).deleteRecursively()

    fun safeResolve(relative: String): File {
        val normalized = relative.trim().trimStart('/')
        val candidate = File(root, normalized).canonicalFile
        if (candidate != root.canonicalFile && !candidate.path.startsWith(root.canonicalPath + File.separator)) {
            throw SecurityException("Path escapes the workspace")
        }
        return candidate
    }

    fun relativePath(file: File): String = file.relativeTo(root).invariantSeparatorsPath

    fun importUri(uri: Uri): File {
        importsDir.mkdirs()
        val resolver = context.contentResolver
        var name = "picked-file"
        resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (index >= 0) name = cursor.getString(index) ?: name
            }
        }
        val safeName = name.replace(Regex("[^A-Za-z0-9._-]"), "_").take(96).ifBlank { "picked-file" }
        var target = File(importsDir, safeName)
        var counter = 1
        while (target.exists()) {
            val dot = safeName.lastIndexOf('.')
            val stem = if (dot > 0) safeName.substring(0, dot) else safeName
            val ext = if (dot > 0) safeName.substring(dot) else ""
            target = File(importsDir, "$stem-${counter}$ext")
            counter++
        }
        resolver.openInputStream(uri)?.use { input ->
            target.outputStream().use { output -> input.copyTo(output) }
        } ?: throw IOException("Cannot read the selected file")
        return target
    }

    fun importText(uri: Uri): String = context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
        ?: throw IOException("Cannot open the selected document")

    fun persistUri(uri: Uri, content: String) {
        context.contentResolver.openOutputStream(uri, "wt")?.bufferedWriter()?.use { it.write(content) }
            ?: throw IOException("Cannot write to the selected document")
    }

    fun displayName(uri: Uri, fallback: String = "document.txt"): String {
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (index >= 0) return cursor.getString(index) ?: fallback
            }
        }
        return fallback
    }
}
