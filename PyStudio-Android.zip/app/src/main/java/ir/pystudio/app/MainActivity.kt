package ir.pystudio.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import ir.pystudio.app.ui.PyStudioRoot
import ir.pystudio.app.ui.theme.Ink
import ir.pystudio.app.ui.theme.Lime
import ir.pystudio.app.ui.theme.PyStudioTheme
import ir.pystudio.app.ui.theme.TextSecondary

class MainActivity : ComponentActivity() {

    private val viewModel: StudioViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        val startupError = runCatching {
            if (!Python.isStarted()) Python.start(AndroidPlatform(applicationContext))
        }.exceptionOrNull()

        setContent {
            PyStudioTheme {
                if (startupError != null) {
                    Box(Modifier.fillMaxSize().background(Ink), contentAlignment = Alignment.Center) {
                        Column(
                            modifier = Modifier.padding(28.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Text("PyStudio", color = Lime)
                            Text("The embedded Python runtime could not start.", color = Color(0xFFFF8177))
                            Text(startupError.message ?: startupError.javaClass.simpleName, color = TextSecondary)
                            Text("Install the arm64-v8a release APK on a physical Android device.", color = TextSecondary)
                        }
                    }
                } else {
                    val vm = remember { viewModel }
                    PyStudioRoot(vm)
                }
            }
        }
    }
}
