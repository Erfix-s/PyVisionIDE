package ir.pystudio.app.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

val Ink = Color(0xFF080B0A)
val Surface = Color(0xFF0F1311)
val SurfaceRaised = Color(0xFF151B17)
val SurfaceHigh = Color(0xFF1C241F)
val Border = Color(0xFF28332B)
val BorderSoft = Color(0xFF1B241E)
val Lime = Color(0xFF9BE564)
val LimeDeep = Color(0xFF23361F)
val Amber = Color(0xFFF6C85F)
val Sky = Color(0xFF7CC7FF)
val Coral = Color(0xFFFF8177)
val TextPrimary = Color(0xFFE9F0EA)
val TextSecondary = Color(0xFF9AAB9F)
val TextFaint = Color(0xFF65756B)

private val StudioColors = darkColorScheme(
    primary = Lime,
    onPrimary = Color(0xFF0C1608),
    primaryContainer = LimeDeep,
    onPrimaryContainer = Lime,
    secondary = Amber,
    onSecondary = Color(0xFF1B1403),
    tertiary = Sky,
    background = Ink,
    onBackground = TextPrimary,
    surface = Surface,
    onSurface = TextPrimary,
    surfaceVariant = SurfaceRaised,
    onSurfaceVariant = TextSecondary,
    surfaceContainer = SurfaceRaised,
    surfaceContainerHigh = SurfaceHigh,
    outline = Border,
    outlineVariant = BorderSoft,
    error = Coral,
    onError = Color(0xFF2A0907)
)

@Composable
fun PyStudioTheme(content: @Composable () -> Unit) {
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = Ink.toArgb()
            window.navigationBarColor = Ink.toArgb()
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = false
            WindowCompat.getInsetsController(window, view).isAppearanceLightNavigationBars = false
        }
    }
    MaterialTheme(colorScheme = StudioColors, content = content)
}
