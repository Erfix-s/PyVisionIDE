package ir.pystudio.app.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.AttachFile
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.CreateNewFolder
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.InsertDriveFile
import androidx.compose.material.icons.rounded.Save
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import ir.pystudio.app.StudioViewModel
import ir.pystudio.app.data.WorkspaceEntry
import ir.pystudio.app.ui.theme.Amber
import ir.pystudio.app.ui.theme.BorderSoft
import ir.pystudio.app.ui.theme.Coral
import ir.pystudio.app.ui.theme.Lime
import ir.pystudio.app.ui.theme.LimeDeep
import ir.pystudio.app.ui.theme.Surface
import ir.pystudio.app.ui.theme.SurfaceHigh
import ir.pystudio.app.ui.theme.SurfaceRaised
import ir.pystudio.app.ui.theme.TextFaint
import ir.pystudio.app.ui.theme.TextPrimary
import ir.pystudio.app.ui.theme.TextSecondary

@Composable
fun EditorScreen(vm: StudioViewModel) {
    var showWorkspace by remember { mutableStateOf(false) }
    var showNewFile by remember { mutableStateOf(false) }
    var pendingDelete by remember { mutableStateOf<WorkspaceEntry?>(null) }

    val openCode = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let(vm::openDocument)
    }
    val saveCode = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/x-python")) { uri ->
        uri?.let(vm::saveDocument)
    }
    val pickAnyFile = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.let { selected ->
            vm.importPickedFile(selected) { path -> vm.insertFileReference(path) }
        }
    }

    Column(Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(41.dp)
                .background(SurfaceRaised)
                .padding(start = 11.dp, end = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Rounded.Description, null, tint = Amber, modifier = Modifier.size(15.dp))
            Spacer(Modifier.width(7.dp))
            Text(
                vm.fileName,
                color = TextPrimary,
                fontFamily = FontFamily.Monospace,
                fontSize = 12.sp,
                maxLines = 1,
                modifier = Modifier.weight(1f)
            )
            if (vm.dirty) {
                Box(Modifier.padding(start = 6.dp).size(5.dp).clip(CircleShape).background(Amber))
            }
            Spacer(Modifier.width(8.dp))
            IconButton(onClick = { showWorkspace = true }, modifier = Modifier.size(32.dp)) {
                Icon(Icons.Rounded.FolderOpen, "Workspace", tint = TextSecondary, modifier = Modifier.size(17.dp))
            }
            IconButton(onClick = { showNewFile = true }, modifier = Modifier.size(32.dp)) {
                Icon(Icons.Rounded.Add, "New file", tint = TextSecondary, modifier = Modifier.size(18.dp))
            }
        }
        Box(Modifier.fillMaxWidth().height(1.dp).background(BorderSoft))

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .background(Surface)
                .padding(horizontal = 8.dp, vertical = 7.dp),
            horizontalArrangement = Arrangement.spacedBy(5.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            EditorAction("Open", Icons.Rounded.FolderOpen) {
                openCode.launch(arrayOf("*/*"))
            }
            EditorAction("Save as", Icons.Rounded.Save) { saveCode.launch(vm.fileName) }
            EditorAction("Insert file", Icons.Rounded.AttachFile, accent = true) {
                pickAnyFile.launch("*/*")
            }
            EditorAction("Files", Icons.Rounded.Folder) { showWorkspace = true }
            Box(
                Modifier
                    .padding(start = 4.dp)
                    .size(4.dp)
                    .clip(CircleShape)
                    .background(TextFaint)
            )
            Text(
                if (vm.dirty) "modified" else "saved",
                color = if (vm.dirty) Amber else TextFaint,
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace
            )
        }
        Box(Modifier.fillMaxWidth().height(1.dp).background(BorderSoft))

        StudioCodeEditor(vm, Modifier.weight(1f))

        val call = vm.enclosingCallName()
        if (call != null) {
            Surface(color = Color(0xFF14200F), modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(Modifier.size(6.dp).clip(CircleShape).background(Lime))
                    Spacer(Modifier.width(7.dp))
                    Text(
                        "Cursor in $call( )",
                        color = TextSecondary,
                        fontSize = 10.5.sp,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.weight(1f)
                    )
                    Text(
                        "Insert picked file",
                        color = Lime,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .clickable { pickAnyFile.launch("*/*") }
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }
        }

        StatusBar(vm)
    }

    if (showWorkspace) {
        WorkspaceDialog(
            files = vm.files,
            activeName = vm.fileName,
            onClose = { showWorkspace = false },
            onOpen = { entry ->
                if (!entry.file.isDirectory) {
                    vm.loadFile(entry.relativePath)
                    showWorkspace = false
                }
            },
            onDelete = { pendingDelete = it },
            onCreate = {
                showWorkspace = false
                showNewFile = true
            }
        )
    }

    if (showNewFile) {
        NewFileDialog(
            onDismiss = { showNewFile = false },
            onCreate = { name ->
                vm.newFile(name)
                showNewFile = false
            }
        )
    }

    pendingDelete?.let { target ->
        AlertDialog(
            onDismissRequest = { pendingDelete = null },
            containerColor = SurfaceHigh,
            title = { Text("Delete file?", color = TextPrimary) },
            text = { Text("${target.relativePath} will be permanently removed from this device.", color = TextSecondary) },
            confirmButton = {
                TextButton(onClick = {
                    vm.deleteFile(target.relativePath)
                    pendingDelete = null
                }) { Text("Delete", color = Coral) }
            },
            dismissButton = {
                TextButton(onClick = { pendingDelete = null }) { Text("Cancel", color = TextSecondary) }
            }
        )
    }
}

@Composable
private fun EditorAction(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    accent: Boolean = false,
    onClick: () -> Unit
) {
    Surface(
        color = if (accent) LimeDeep else SurfaceRaised,
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier.clip(RoundedCornerShape(8.dp)).clickable(onClick = onClick)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 9.dp, vertical = 7.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                icon,
                contentDescription = label,
                tint = if (accent) Lime else TextSecondary,
                modifier = Modifier.size(14.dp)
            )
            Spacer(Modifier.width(5.dp))
            Text(
                label,
                color = if (accent) Lime else TextPrimary,
                fontSize = 10.5.sp,
                fontWeight = FontWeight.Medium
            )
        }
    }
}

@Composable
private fun StatusBar(vm: StudioViewModel) {
    val (line, column) = vm.lineAndColumn()
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(27.dp)
            .background(Surface)
            .padding(horizontal = 11.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            "Ln $line, Col $column",
            color = TextFaint,
            fontSize = 9.5.sp,
            fontFamily = FontFamily.Monospace
        )
        Spacer(Modifier.weight(1f))
        Text(
            "Python 3.10",
            color = Lime,
            fontSize = 9.5.sp,
            fontFamily = FontFamily.Monospace
        )
        Spacer(Modifier.width(10.dp))
        Text("UTF-8", color = TextFaint, fontSize = 9.5.sp, fontFamily = FontFamily.Monospace)
        Spacer(Modifier.width(10.dp))
        Text(
            "${vm.buffer.lines().size} lines",
            color = TextFaint,
            fontSize = 9.5.sp,
            fontFamily = FontFamily.Monospace
        )
    }
}

@Composable
private fun NewFileDialog(onDismiss: () -> Unit, onCreate: (String) -> Unit) {
    var name by remember { mutableStateOf("script.py") }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = SurfaceHigh,
        title = { Text("New Python file", color = TextPrimary) },
        text = {
            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                singleLine = true,
                label = { Text("File name") },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary,
                    focusedBorderColor = Lime,
                    unfocusedBorderColor = BorderSoft,
                    focusedLabelColor = Lime,
                    unfocusedLabelColor = TextFaint
                )
            )
        },
        confirmButton = {
            TextButton(onClick = { onCreate(name) }) { Text("Create", color = Lime) }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel", color = TextSecondary) }
        }
    )
}

@Composable
private fun WorkspaceDialog(
    files: List<WorkspaceEntry>,
    activeName: String,
    onClose: () -> Unit,
    onOpen: (WorkspaceEntry) -> Unit,
    onDelete: (WorkspaceEntry) -> Unit,
    onCreate: () -> Unit
) {
    Dialog(onDismissRequest = onClose) {
        Surface(
            color = SurfaceHigh,
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Workspace", color = TextPrimary, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                        Text("/data/…/files/workspace", color = TextFaint, fontFamily = FontFamily.Monospace, fontSize = 9.5.sp)
                    }
                    IconButton(onClick = onCreate) {
                        Icon(Icons.Rounded.CreateNewFolder, "New file", tint = Lime)
                    }
                    IconButton(onClick = onClose) {
                        Icon(Icons.Rounded.Close, "Close", tint = TextSecondary)
                    }
                }
                LazyColumn(modifier = Modifier.heightIn(max = 390.dp)) {
                    items(files, key = { it.relativePath }) { entry ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .clickable(enabled = !entry.file.isDirectory) { onOpen(entry) }
                                .padding(vertical = 8.dp, horizontal = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                if (entry.file.isDirectory) Icons.Rounded.Folder else Icons.Rounded.InsertDriveFile,
                                null,
                                tint = if (entry.file.isDirectory) Amber else if (entry.relativePath == activeName) Lime else TextSecondary,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(Modifier.width(9.dp))
                            Column(Modifier.weight(1f)) {
                                Text(
                                    entry.relativePath,
                                    color = if (entry.relativePath == activeName) Lime else TextPrimary,
                                    fontSize = 12.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                                Text(
                                    if (entry.file.isDirectory) "directory" else "${entry.file.length()} bytes",
                                    color = TextFaint,
                                    fontSize = 9.sp
                                )
                            }
                            if (!entry.file.isDirectory) {
                                IconButton(onClick = { onDelete(entry) }, modifier = Modifier.size(30.dp)) {
                                    Icon(Icons.Rounded.Delete, "Delete", tint = TextFaint, modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                    }
                    if (files.isEmpty()) {
                        item { Text("Workspace is empty", color = TextSecondary, modifier = Modifier.padding(12.dp)) }
                    }
                }
                Text(
                    "Picked files are copied to /workspace/imports so Python always gets a real path.",
                    color = TextFaint,
                    fontSize = 9.5.sp,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }
        }
    }
}
