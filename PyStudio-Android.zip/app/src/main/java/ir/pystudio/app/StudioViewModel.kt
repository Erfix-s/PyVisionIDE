package ir.pystudio.app

import android.app.Application
import android.net.Uri
import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.text.TextRange
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import ir.pystudio.app.data.BundledLibraries
import ir.pystudio.app.data.OutputItem
import ir.pystudio.app.data.OutputStream
import ir.pystudio.app.data.PythonLibrary
import ir.pystudio.app.data.StudioTab
import ir.pystudio.app.data.TerminalEntry
import ir.pystudio.app.data.TerminalKind
import ir.pystudio.app.data.WorkspaceEntry
import ir.pystudio.app.data.WorkspaceRepository
import ir.pystudio.app.python.PythonBridge
import ir.pystudio.app.python.PythonRunner
import ir.pystudio.app.shell.ShellOutcome
import ir.pystudio.app.shell.ShellSession
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.util.Locale
import kotlin.math.max

class StudioViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = WorkspaceRepository(application)
    private val shell = ShellSession(repository)
    private val pythonRunner = PythonRunner(repository.root)

    var activeTab by mutableStateOf(StudioTab.EDITOR)
    var buffer by mutableStateOf("")
    var fileName by mutableStateOf("welcome.py")
    var selection by mutableStateOf(TextRange(0))
    var dirty by mutableStateOf(false)
    var isRunning by mutableStateOf(false)
        private set
    var wasStopped by mutableStateOf(false)
        private set
    var outputItems = mutableStateListOf<OutputItem>()
    var terminalEntries = mutableStateListOf<TerminalEntry>()
    var cwd by mutableStateOf("")
        private set
    var files by mutableStateOf<List<WorkspaceEntry>>(emptyList())
        private set
    var uiMessage by mutableStateOf<String?>(null)
    var libraryVersions = mutableStateMapOf<String, String>()
    var librariesLoading by mutableStateOf(false)
        private set
    var lastRunMillis by mutableStateOf(0L)
        private set

    val libraries: List<PythonLibrary> = BundledLibraries

    private var cancelRequested = false
    private var outputCharCount = 0
    private var outputTruncated = false
    private var versionsLoaded = false
    private val mainHandler = Handler(Looper.getMainLooper())
    private val outputLimit = 240_000

    init {
        refreshFiles()
        runCatching { loadFile("welcome.py", silent = true) }
        terminalEntries += TerminalEntry("PyStudio shell · Python 3.10 · Chaquopy", TerminalKind.INFO)
        terminalEntries += TerminalEntry("Type 'help' for commands. Workspace: /workspace", TerminalKind.INFO)
    }

    fun refreshFiles() {
        files = repository.list()
    }

    fun loadFile(relative: String, silent: Boolean = false) {
        runCatching {
            buffer = repository.read(relative)
            fileName = relative.substringAfterLast('/')
            selection = TextRange(0)
            dirty = false
            if (!silent) activeTab = StudioTab.EDITOR
        }.onFailure { uiMessage = it.message ?: "Could not open file" }
    }

    fun newFile(name: String) {
        val cleaned = name.trim().ifBlank { "main.py" }.let {
            if (it.endsWith(".py")) it else "$it.py"
        }.replace(Regex("[^A-Za-z0-9._-]"), "_")
        val starter = buildString {
            appendLine("# ${cleaned.removeSuffix(".py")} — created with PyStudio.")
            appendLine()
            appendLine("def main():")
            appendLine("    print(\"Hello from PyStudio!\")")
            appendLine()
            appendLine()
            appendLine("if __name__ == \"__main__\":")
            appendLine("    main()")
        }
        runCatching {
            repository.write(cleaned, starter)
            refreshFiles()
            loadFile(cleaned, silent = true)
            dirty = true
            uiMessage = "Created $cleaned"
        }.onFailure { uiMessage = it.message }
    }

    fun deleteFile(relative: String) {
        runCatching {
            repository.delete(relative)
            refreshFiles()
            if (relative == fileName) loadFile("welcome.py", silent = true)
            uiMessage = "Deleted $relative"
        }.onFailure { uiMessage = it.message }
    }

    fun persistDraft() {
        val safeName = fileName.substringAfterLast('/').ifBlank { "main.py" }
        runCatching {
            repository.write(safeName, buffer)
            fileName = safeName
            dirty = false
            refreshFiles()
        }.onFailure { uiMessage = it.message }
    }

    fun openDocument(uri: Uri) {
        viewModelScope.launch {
            runCatching {
                val name = repository.displayName(uri).substringAfterLast('/')
                val content = withContext(Dispatchers.IO) { repository.importText(uri) }
                buffer = content
                fileName = name.let { if (it.endsWith(".py")) it else "$it.py" }
                    .replace(Regex("[^A-Za-z0-9._-]"), "_")
                selection = TextRange(0)
                dirty = true
                activeTab = StudioTab.EDITOR
                uiMessage = "Opened $fileName"
            }.onFailure { uiMessage = it.message ?: "Could not open document" }
        }
    }

    fun saveDocument(uri: Uri) {
        viewModelScope.launch {
            runCatching {
                withContext(Dispatchers.IO) { repository.persistUri(uri, buffer) }
                dirty = false
                uiMessage = "Exported $fileName"
            }.onFailure { uiMessage = it.message ?: "Could not save document" }
        }
    }

    /** Copies any SAF file into the real filesystem and returns its absolute path. */
    fun importPickedFile(uri: Uri, onReady: (String) -> Unit) {
        viewModelScope.launch {
            runCatching {
                val file = withContext(Dispatchers.IO) { repository.importUri(uri) }
                refreshFiles()
                onReady(file.absolutePath)
                uiMessage = "Imported ${file.name}"
            }.onFailure { uiMessage = it.message ?: "Could not import file" }
        }
    }

    /**
     * Inserts a quoted path at the cursor. If the cursor is inside a function
     * call, it inserts a properly separated argument, e.g. cv2.imread("...").
     */
    fun insertFileReference(path: String) {
        val text = buffer
        val cursor = selection.start.coerceIn(0, text.length)
        val escaped = path.replace("\\", "\\\\").replace("\"", "\\\"")
        val literal = "\"$escaped\""

        var depth = 0
        var openIndex = -1
        for (index in cursor - 1 downTo 0) {
            when (text[index]) {
                ')' -> depth++
                '(' -> {
                    if (depth == 0) { openIndex = index; break }
                    depth--
                }
            }
        }

        var prefix = ""
        if (openIndex >= 0) {
            var probe = cursor - 1
            while (probe > openIndex && text[probe].isWhitespace()) probe--
            if (probe > openIndex && text[probe] != '(' && text[probe] != ',') prefix = ", "
        }

        val insertion = prefix + literal
        buffer = text.substring(0, cursor) + insertion + text.substring(cursor)
        selection = TextRange(cursor + insertion.length)
        dirty = true
        activeTab = StudioTab.EDITOR
        uiMessage = "Path inserted: ${path.substringAfterLast('/')}"
    }

    fun runCurrent() {
        persistDraft()
        runSource(buffer, fileName)
    }

    fun stopExecution() {
        if (!isRunning) return
        cancelRequested = true
        wasStopped = true
        appendOutputNote("Stopping…")
    }

    fun runRelative(relative: String) {
        runCatching { repository.read(relative) }
            .onSuccess { runSource(it, relative) }
            .onFailure { uiMessage = it.message }
    }

    private fun runSource(source: String, label: String) {
        if (isRunning) {
            uiMessage = "A process is already running"
            return
        }
        outputItems.clear()
        outputCharCount = 0
        outputTruncated = false
        cancelRequested = false
        wasStopped = false
        isRunning = true
        activeTab = StudioTab.OUTPUT
        outputItems += OutputItem.Note("Running $label")
        val start = System.currentTimeMillis()

        val bridge = PythonBridge(
            onStream = { text, isError ->
                mainHandler.post { appendStream(text, isError) }
            },
            onImage = { path ->
                mainHandler.post {
                    val file = java.io.File(path)
                    if (file.isFile) outputItems += OutputItem.Image(file.absolutePath, file.name)
                }
            },
            cancellationRequested = { cancelRequested }
        )

        viewModelScope.launch {
            withContext(Dispatchers.IO) {
                runCatching { pythonRunner.run(source, bridge) }
                    .onFailure { error ->
                        mainHandler.post {
                            appendStream("\nRuntime error: ${error.message ?: error.javaClass.simpleName}\n", true)
                        }
                    }
            }
            val elapsed = System.currentTimeMillis() - start
            lastRunMillis = elapsed
            isRunning = false
            val stopped = wasStopped
            cancelRequested = false
            val secs = String.format(Locale.US, "%.2f", elapsed / 1000.0)
            outputItems += OutputItem.Note(if (stopped) "Process stopped · ${secs}s" else "Process finished · ${secs}s")
        }
    }

    private fun appendStream(text: String, isError: Boolean) {
        if (text.isEmpty() || outputTruncated) return
        if (outputCharCount + text.length > outputLimit) {
            val remaining = max(0, outputLimit - outputCharCount)
            val slice = text.take(remaining)
            if (slice.isNotEmpty()) addText(slice, isError)
            outputItems += OutputItem.Note("Output truncated at ${outputLimit / 1000}K characters")
            outputTruncated = true
            return
        }
        outputCharCount += text.length
        addText(text, isError)
    }

    private fun addText(text: String, isError: Boolean) {
        val stream = if (isError) OutputStream.STDERR else OutputStream.STDOUT
        val last = outputItems.lastOrNull()
        if (last is OutputItem.Text && last.stream == stream) {
            outputItems[outputItems.lastIndex] = last.copy(text = last.text + text)
        } else {
            outputItems += OutputItem.Text(text, stream)
        }
    }

    private fun appendOutputNote(text: String) {
        outputItems += OutputItem.Note(text)
    }

    fun clearOutput() {
        outputItems.clear()
        outputCharCount = 0
        outputTruncated = false
    }

    fun submitShell(raw: String) {
        terminalEntries += TerminalEntry("${shell.prompt()} $raw", TerminalKind.INPUT)
        when (val outcome = shell.execute(raw)) {
            is ShellOutcome.Lines -> outcome.entries.forEach { (text, kind) ->
                terminalEntries += TerminalEntry(text, kind)
            }
            is ShellOutcome.RunPythonFile -> {
                runRelative(outcome.relativePath)
                terminalEntries += TerminalEntry("→ ${outcome.relativePath} launched in Output", TerminalKind.INFO)
            }
            ShellOutcome.Clear -> terminalEntries.clear()
        }
        cwd = shell.cwd
        refreshFiles()
    }

    fun clearTerminal() {
        terminalEntries.clear()
    }

    fun refreshLibraries(force: Boolean = false) {
        if (librariesLoading || (versionsLoaded && !force)) return
        librariesLoading = true
        viewModelScope.launch {
            runCatching {
                val jsonText = withContext(Dispatchers.IO) { pythonRunner.versions() }
                val json = JSONObject(jsonText)
                mapOf(
                    "numpy" to "numpy",
                    "cv2" to "OpenCV",
                    "matplotlib" to "matplotlib",
                    "PIL" to "Pillow",
                    "pandas" to "pandas",
                    "requests" to "Requests"
                ).forEach { (key, alias) ->
                    if (json.has(alias)) libraryVersions[key] = json.optString(alias)
                }
                versionsLoaded = true
            }.onFailure { uiMessage = "Could not read package versions" }
            librariesLoading = false
        }
    }


    /** Returns the function name when the cursor sits inside its parentheses. */
    fun enclosingCallName(): String? {
        val text = buffer
        val cursor = selection.start.coerceIn(0, text.length)
        var depth = 0
        var openIndex = -1
        for (index in cursor - 1 downTo 0) {
            when (text[index]) {
                ')' -> depth++
                '(' -> {
                    if (depth == 0) { openIndex = index; break }
                    depth--
                }
            }
        }
        if (openIndex < 0) return null
        val name = text.substring(0, openIndex).trimEnd().takeLastWhile {
            it.isLetterOrDigit() || it == '_' || it == '.'
        }
        return name.ifBlank { null }
    }

    fun consumeMessage() {
        uiMessage = null
    }

    fun lineAndColumn(): Pair<Int, Int> {
        val cursor = selection.start.coerceIn(0, buffer.length)
        val before = buffer.substring(0, cursor)
        val line = before.count { it == '\n' } + 1
        val column = cursor - before.lastIndexOf('\n')
        return line to column
    }
}
