package ir.pystudio.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Memory
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ir.pystudio.app.StudioViewModel
import ir.pystudio.app.data.LibraryTone
import ir.pystudio.app.data.PythonLibrary
import ir.pystudio.app.ui.theme.Amber
import ir.pystudio.app.ui.theme.BorderSoft
import ir.pystudio.app.ui.theme.Coral
import ir.pystudio.app.ui.theme.Lime
import ir.pystudio.app.ui.theme.Sky
import ir.pystudio.app.ui.theme.Surface
import ir.pystudio.app.ui.theme.SurfaceHigh
import ir.pystudio.app.ui.theme.SurfaceRaised
import ir.pystudio.app.ui.theme.TextFaint
import ir.pystudio.app.ui.theme.TextPrimary
import ir.pystudio.app.ui.theme.TextSecondary

@Composable
fun LibrariesScreen(vm: StudioViewModel) {
    LaunchedEffect(Unit) { vm.refreshLibraries() }

    Column(Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier.fillMaxWidth().background(Surface).padding(start = 14.dp, end = 6.dp, top = 11.dp, bottom = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text("Bundled libraries", color = TextPrimary, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Text("Native wheels compiled into this APK", color = TextFaint, fontSize = 10.sp)
            }
            if (vm.librariesLoading) {
                CircularProgressIndicator(Modifier.size(16.dp), color = Lime, strokeWidth = 1.5.dp)
            }
            IconButton(onClick = { vm.refreshLibraries(force = true) }, enabled = !vm.librariesLoading) {
                Icon(Icons.Rounded.Refresh, "Refresh versions", tint = TextSecondary, modifier = Modifier.size(19.dp))
            }
        }
        Box(Modifier.fillMaxWidth().height(1.dp).background(BorderSoft))

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            item {
                Surface(color = Color(0xFF131E11), shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.Top) {
                        Box(
                            Modifier.size(32.dp).clip(RoundedCornerShape(8.dp)).background(Color(0xFF22341C)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Rounded.Memory, null, tint = Lime, modifier = Modifier.size(17.dp))
                        }
                        Spacer(Modifier.width(10.dp))
                        Column {
                            Text("No runtime downloads", color = Lime, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                            Text(
                                "These packages ship inside the signed APK, so plain imports work offline. Adding a package is a Gradle change followed by a new CI build.",
                                color = TextSecondary,
                                fontSize = 10.5.sp,
                                lineHeight = 16.sp
                            )
                        }
                    }
                }
            }
            items(vm.libraries) { library ->
                LibraryCard(library, vm.libraryVersions[library.importName])
            }
            item {
                Surface(color = Surface, shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(13.dp)) {
                        Text("Add another library", color = TextPrimary, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                        Text(
                            "Paste this into app/build.gradle, push the ZIP update, and Actions will ship a new signed APK.",
                            color = TextFaint,
                            fontSize = 10.sp,
                            lineHeight = 15.sp,
                            modifier = Modifier.padding(top = 3.dp, bottom = 8.dp)
                        )
                        SelectionContainer {
                            Text(
                                "chaquopy {\n  defaultConfig {\n    pip {\n      install \"scipy\"\n    }\n  }\n}",
                                color = Color(0xFFB8E986),
                                fontFamily = FontFamily.Monospace,
                                fontSize = 10.sp,
                                lineHeight = 15.sp,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(Color(0xFF0A0F0B))
                                    .padding(10.dp)
                            )
                        }
                        Text(
                            "The package must have an Android wheel in the Chaquopy repository.",
                            color = TextFaint,
                            fontSize = 9.sp,
                            modifier = Modifier.padding(top = 7.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun LibraryCard(library: PythonLibrary, version: String?) {
    Surface(color = SurfaceHigh, shape = RoundedCornerShape(11.dp), modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(11.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier
                    .size(39.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(toneColor(library.tone).copy(alpha = 0.12f)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    library.name.take(2),
                    color = toneColor(library.tone),
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
            }
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(library.name, color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.width(6.dp))
                    Text(
                        library.badge,
                        color = toneColor(library.tone),
                        fontSize = 8.sp,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(toneColor(library.tone).copy(alpha = 0.11f))
                            .padding(horizontal = 4.dp, vertical = 1.dp)
                    )
                }
                Text(library.description, color = TextFaint, fontSize = 9.5.sp, lineHeight = 14.sp)
                Row(Modifier.padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.CheckCircle, null, tint = Lime, modifier = Modifier.size(11.dp))
                    Spacer(Modifier.width(3.dp))
                    Text(
                        "import ${library.importName}",
                        color = TextSecondary,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 9.sp
                    )
                }
            }
            Column(horizontalAlignment = Alignment.End) {
                Box(Modifier.size(5.dp).clip(CircleShape).background(Lime))
                Spacer(Modifier.width(4.dp))
                Text(
                    version ?: "bundled",
                    color = TextFaint,
                    fontSize = 8.5.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
        }
    }
}

private fun toneColor(tone: LibraryTone): Color = when (tone) {
    LibraryTone.GREEN -> Lime
    LibraryTone.AMBER -> Amber
    LibraryTone.BLUE -> Sky
    LibraryTone.CORAL -> Coral
}
