package ir.pystudio.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Code
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.Memory
import androidx.compose.material.icons.rounded.PhotoLibrary
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Save
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material.icons.rounded.Terminal
import androidx.compose.material.icons.rounded.Widgets
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ir.pystudio.app.StudioViewModel
import ir.pystudio.app.data.StudioTab
import ir.pystudio.app.ui.theme.Amber
import ir.pystudio.app.ui.theme.BorderSoft
import ir.pystudio.app.ui.theme.Coral
import ir.pystudio.app.ui.theme.Ink
import ir.pystudio.app.ui.theme.Lime
import ir.pystudio.app.ui.theme.Surface
import ir.pystudio.app.ui.theme.SurfaceHigh
import ir.pystudio.app.ui.theme.SurfaceRaised
import ir.pystudio.app.ui.theme.TextFaint
import ir.pystudio.app.ui.theme.TextPrimary
import ir.pystudio.app.ui.theme.TextSecondary

@Composable
fun PyStudioRoot(vm: StudioViewModel) {
    val snackbar = remember { SnackbarHostState() }
    LaunchedEffect(vm.uiMessage) {
        val message = vm.uiMessage
        if (message != null) {
            snackbar.showSnackbar(message)
            vm.consumeMessage()
        }
    }

    Scaffold(
        containerColor = Ink,
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        snackbarHost = { SnackbarHost(snackbar) { data -> StudioSnackbar(data.visuals.message) } },
        topBar = { StudioTopBar(vm) },
        bottomBar = { StudioBottomBar(vm) }
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(Ink)
                .imePadding()
        ) {
            when (vm.activeTab) {
                StudioTab.EDITOR -> EditorScreen(vm)
                StudioTab.OUTPUT -> OutputScreen(vm)
                StudioTab.TERMINAL -> TerminalScreen(vm)
                StudioTab.LIBRARIES -> LibrariesScreen(vm)
            }
        }
    }
}

@Composable
private fun StudioSnackbar(message: String) {
    Surface(
        color = SurfaceHigh,
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.padding(12.dp)
    ) {
        Text(
            text = message,
            color = TextPrimary,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
            fontSize = 13.sp
        )
    }
}

@Composable
private fun StudioTopBar(vm: StudioViewModel) {
    Surface(color = Surface) {
        Column(Modifier.statusBarsPadding()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(62.dp)
                    .padding(start = 14.dp, end = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                LogoMark()
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            "PyStudio",
                            color = TextPrimary,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 0.2.sp
                        )
                        Spacer(Modifier.width(7.dp))
                        Surface(color = SurfaceRaised, shape = RoundedCornerShape(5.dp)) {
                            Text(
                                "3.10",
                                color = Lime,
                                fontSize = 9.sp,
                                fontFamily = FontFamily.Monospace,
                                modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                            )
                        }
                    }
                    Text(
                        if (vm.isRunning) "Running on-device…" else "Python, on your phone",
                        color = if (vm.isRunning) Lime else TextFaint,
                        fontSize = 10.5.sp
                    )
                }
                IconButton(onClick = { vm.persistDraft() }) {
                    Icon(Icons.Rounded.Save, contentDescription = "Save", tint = TextSecondary)
                }
                Button(
                    onClick = { if (vm.isRunning) vm.stopExecution() else vm.runCurrent() },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (vm.isRunning) Coral else Lime,
                        contentColor = if (vm.isRunning) Color(0xFF200B08) else Color(0xFF0B1507)
                    ),
                    shape = RoundedCornerShape(11.dp),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 13.dp, vertical = 8.dp)
                ) {
                    Icon(
                        if (vm.isRunning) Icons.Rounded.Stop else Icons.Rounded.PlayArrow,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(Modifier.width(4.dp))
                    Text(if (vm.isRunning) "Stop" else "Run", fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                }
            }
            Box(Modifier.fillMaxWidth().height(1.dp).background(BorderSoft))
        }
    }
}

@Composable
private fun LogoMark() {
    Box(
        modifier = Modifier
            .size(34.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(
                androidx.compose.ui.graphics.Brush.linearGradient(
                    listOf(Color(0xFF263A22), Color(0xFF141D16))
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        Text(
            "P",
            color = Lime,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            fontSize = 18.sp
        )
        Box(
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(5.dp)
                .size(5.dp)
                .clip(CircleShape)
                .background(Amber)
        )
    }
}

@Composable
private fun StudioBottomBar(vm: StudioViewModel) {
    Surface(color = Surface) {
        Column(Modifier.navigationBarsPadding()) {
            Box(Modifier.fillMaxWidth().height(1.dp).background(BorderSoft))
            NavigationBar(
                containerColor = Surface,
                tonalElevation = 0.dp,
                windowInsets = WindowInsets(0, 0, 0, 0)
            ) {
                StudioTab.entries.forEach { tab ->
                    val selected = vm.activeTab == tab
                    NavigationBarItem(
                        selected = selected,
                        onClick = { vm.activeTab = tab },
                        icon = {
                            Box {
                                Icon(
                                    imageVector = when (tab) {
                                        StudioTab.EDITOR -> Icons.Rounded.Code
                                        StudioTab.OUTPUT -> Icons.Rounded.PhotoLibrary
                                        StudioTab.TERMINAL -> Icons.Rounded.Terminal
                                        StudioTab.LIBRARIES -> Icons.Rounded.Widgets
                                    },
                                    contentDescription = tab.label,
                                    modifier = Modifier.size(21.dp)
                                )
                                if (tab == StudioTab.OUTPUT && vm.isRunning) {
                                    Box(
                                        Modifier
                                            .align(Alignment.TopEnd)
                                            .size(6.dp)
                                            .clip(CircleShape)
                                            .background(Lime)
                                    )
                                }
                            }
                        },
                        label = {
                            Text(
                                when (tab) {
                                    StudioTab.EDITOR -> "Code"
                                    StudioTab.OUTPUT -> "Output"
                                    StudioTab.TERMINAL -> "Shell"
                                    StudioTab.LIBRARIES -> "Libs"
                                },
                                fontSize = 10.5.sp,
                                fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Lime,
                            selectedTextColor = Lime,
                            indicatorColor = Color(0xFF1B2A18),
                            unselectedIconColor = TextFaint,
                            unselectedTextColor = TextFaint
                        )
                    )
                }
            }
        }
    }
}
