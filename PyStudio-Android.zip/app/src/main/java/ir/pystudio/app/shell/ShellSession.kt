package ir.pystudio.app.shell

import ir.pystudio.app.data.BundledLibraries
import ir.pystudio.app.data.TerminalKind
import ir.pystudio.app.data.WorkspaceRepository
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

sealed interface ShellOutcome {
    data class Lines(val entries: List<Pair<String, TerminalKind>>) : ShellOutcome
    data class RunPythonFile(val relativePath: String) : ShellOutcome
    data object Clear : ShellOutcome
}

/**
 * A deliberately small, safe shell over the app workspace. This is not a Linux
 * kernel: commands are implemented by the app, and the working directory can
 * never escape the private workspace.
 */
class ShellSession(private val repository: WorkspaceRepository) {

    var cwd: String = ""
        private set

    fun prompt(): String = "/workspace" + if (cwd.isBlank()) "" else "/$cwd"

    fun execute(raw: String): ShellOutcome {
        val line = raw.trim()
        if (line.isBlank()) return ShellOutcome.Lines(emptyList())
        val parts = tokenize(line)
        val command = parts.first().lowercase(Locale.US)
        val args = parts.drop(1)

        return when (command) {
            "help" -> lines(
                "PyStudio shell — available commands",
                "  ls [dir]          list workspace files",
                "  cd [dir]          change directory (supports ..)",
                "  pwd               print current directory",
                "  cat <file>        print a text file",
                "  mkdir <dir>       create a directory",
                "  touch <file>      create an empty file",
                "  rm <path>         delete a file or directory",
                "  python <file.py>  execute a Python file in Output",
                "  pip list          show libraries bundled in the APK",
                "  pip install <pkg> explain how to bundle a library",
                "  echo <text>       print text",
                "  date | uname -a | whoami | clear",
            )
            "pwd" -> lines(prompt())
            "ls" -> runCatching {
                val target = args.firstOrNull()?.let { resolve(it) } ?: cwd
                val entries = repository.list(target)
                if (entries.isEmpty()) "… directory is empty"
                else entries.joinToString("\n") { entry ->
                    val suffix = if (entry.file.isDirectory) "/" else ""
                    val size = if (entry.file.isDirectory) "" else "  ${humanSize(entry.file.length())}"
                    "${entry.file.name}$suffix$size"
                }
            }.getOrElse { error(it.message ?: "ls failed") }
            "cd" -> changeDirectory(args.firstOrNull() ?: "")
            "cat" -> runCatching {
                val target = args.firstOrNull() ?: throw IllegalArgumentException("cat: missing file operand")
                repository.read(resolve(target)).ifBlank { "(empty file)" }
            }.getOrElse { error(it.message ?: "cat failed") }
            "mkdir" -> runCatching {
                val target = args.firstOrNull() ?: throw IllegalArgumentException("mkdir: missing operand")
                repository.mkdir(resolve(target)); "created ${resolve(target)}"
            }.getOrElse { error(it.message ?: "mkdir failed") }
            "touch" -> runCatching {
                val target = args.firstOrNull() ?: throw IllegalArgumentException("touch: missing file operand")
                val file = repository.safeResolve(resolve(target))
                if (!file.exists()) { file.parentFile?.mkdirs(); file.createNewFile() }
                "touched ${repository.relativePath(file)}"
            }.getOrElse { error(it.message ?: "touch failed") }
            "rm" -> runCatching {
                val target = args.firstOrNull() ?: throw IllegalArgumentException("rm: missing operand")
                if (repository.safeResolve(resolve(target)) == repository.root) {
                    throw IllegalArgumentException("rm: refusing to remove the workspace root")
                }
                repository.delete(resolve(target)); "removed $target"
            }.getOrElse { error(it.message ?: "rm failed") }
            "echo" -> lines(line.removePrefix("echo").trim())
            "date" -> lines(SimpleDateFormat("EEE MMM d HH:mm:ss z yyyy", Locale.US).format(Date()))
            "whoami" -> lines("pystudio")
            "uname" -> lines("Android ${android.os.Build.VERSION.RELEASE} ${android.os.Build.SUPPORTED_ABIS.firstOrNull() ?: "aarch64"} · PyStudio")
            "python", "python3" -> {
                val file = args.firstOrNull()
                when {
                    file == null -> lines(
                        "Python 3.10 (Chaquopy, embedded in PyStudio)",
                        "Use: python <file.py>   — or edit and tap Run.",
                    )
                    !file.endsWith(".py", ignoreCase = true) -> error("python: only .py files are supported")
                    else -> ShellOutcome.RunPythonFile(resolve(file))
                }
            }
            "pip", "pip3" -> pip(args)
            "clear" -> ShellOutcome.Clear
            else -> error("$command: command not found. Type 'help'.")
        }
    }

    private fun pip(args: List<String>): ShellOutcome {
        val sub = args.firstOrNull()?.lowercase(Locale.US)
        return when (sub) {
            null, "help" -> lines(
                "pip is build-time in PyStudio.",
                "Run: pip list       to see bundled packages",
                "Run: pip install X  for bundling instructions",
            )
            "list", "freeze" -> lines(
                "Bundled into this APK:",
                *BundledLibraries.map { "  ${it.name.padEnd(12)} · ${it.importName} · ${it.badge}" }.toTypedArray(),
                "",
                "Native wheels are installed by Gradle/Chaquopy at build time.",
            )
            "install" -> {
                val name = args.getOrNull(1) ?: return error("pip: missing package name")
                val known = BundledLibraries.firstOrNull {
                    it.importName.equals(name, true) || it.name.equals(name, true)
                }
                if (known != null) {
                    lines("Requirement already satisfied: ${known.importName} (bundled in the APK)")
                } else {
                    error(
                        "pip install $name: runtime installation is disabled on Android.\n" +
                            "Add install \"$name\" to app/build.gradle → chaquopy → pip, then let GitHub Actions build a new APK."
                    )
                }
            }
            else -> error("pip: unknown command '$sub'")
        }
    }

    private fun changeDirectory(target: String): ShellOutcome {
        if (target.isBlank() || target == "~") { cwd = ""; return lines(prompt()) }
        return runCatching {
            val candidate = resolve(target)
            val file = repository.safeResolve(candidate)
            require(file.isDirectory) { "cd: no such directory: $target" }
            cwd = candidate
            lines(prompt())
        }.getOrElse { error(it.message ?: "cd failed") }
    }

    private fun resolve(target: String): String {
        if (target.startsWith("/workspace")) {
            return target.removePrefix("/workspace").trimStart('/')
        }
        val base = File(repository.root, cwd)
        val resolved = File(base, target).canonicalFile
        if (resolved != repository.root.canonicalFile &&
            !resolved.path.startsWith(repository.root.canonicalPath + File.separator)
        ) {
            throw SecurityException("path is outside /workspace")
        }
        return repository.relativePath(resolved)
    }

    private fun tokenize(line: String): List<String> {
        val result = mutableListOf<String>()
        val current = StringBuilder()
        var quote: Char? = null
        var escaped = false
        line.forEach { char ->
            when {
                escaped -> { current.append(char); escaped = false }
                char == '\\' -> { escaped = true }
                quote != null && char == quote -> quote = null
                quote == null && (char == '"' || char == '\'') -> quote = char
                quote == null && char.isWhitespace() -> {
                    if (current.isNotEmpty()) { result += current.toString(); current.clear() }
                }
                else -> current.append(char)
            }
        }
        if (current.isNotEmpty()) result += current.toString()
        return result
    }

    private fun humanSize(bytes: Long): String = when {
        bytes >= 1024 * 1024 -> "%.1f MB".format(bytes / 1024.0 / 1024.0)
        bytes >= 1024 -> "%.1f KB".format(bytes / 1024.0)
        else -> "$bytes B"
    }

    private fun lines(vararg values: String) = ShellOutcome.Lines(values.map { it to TerminalKind.OUTPUT })
    private fun error(value: String) = ShellOutcome.Lines(listOf(value to TerminalKind.ERROR))
}
