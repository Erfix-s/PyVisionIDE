package ir.pystudio.app.ui

import android.graphics.BitmapFactory
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.DeleteSweep
import androidx.compose.material.icons.rounded.ErrorOutline
import androidx.compose.material.icons.rounded.PhotoLibrary
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import ir.pystudio.app.StudioViewModel
import ir.pystudio.app.data.OutputItem
import ir.pystudio.app.data.OutputStream
import ir.pystudio.app.ui.theme.Amber
import ir.pystudio.app.ui.theme.BorderSoft
import ir.pystudio.app.ui.theme.Coral
import ir.pystudio.app.ui.theme.Lime
import ir.pystudio.app.ui.theme.LimeDeep
import ir.pystudio.app.ui.theme.Surface
import ir.pystudio.app.ui.theme.SurfaceHigh
import ir.pystudio.app.ui.theme.SurfaceRaised
import ir.pystudio.app.ui.theme.TextFaint
import ir.pystudio.app.ui.theme.TextPrimary
import ir.pystudio.app.ui.theme.TextSecondary
import kotlin.math.max

@Composable
fun OutputScreen(vm: StudioViewModel) {
    val listState = rememberLazyListState()
    val clipboard = LocalClipboardManager.current
    var previewImage by remember { mutableStateOf<OutputItem.Image?>(null) }
    var copyPulse by remember { mutableIntStateOf(0) }

    LaunchedEffect(vm.outputItems.size, copyPulse) {
        if (vm.outputItems.isNotEmpty()) {
            runCatching { listState.animateScrollToItem(vm.outputItems.lastIndex) }
        }
    }

    Column(Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Surface)
                .padding(start = 14.dp, end = 5.dp, top = 11.dp, bottom = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Output", color = TextPrimary, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.width(8.dp))
                    if (vm.isRunning) {
                        Surface(color = Color(0xFF1B2A18), shape = RoundedCornerShape(5.dp)) {
                            Row(
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(9.dp),
                                    color = Lime,
                                    strokeWidth = 1.5.dp
                                )
                                Spacer(Modifier.width(4.dp))
                                Text("LIVE", color = Lime, fontSize = 8.5.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
                Text(
                    if (vm.lastRunMillis > 0) "stdout · stderr · figures · last run ${vm.lastRunMillis} ms"
                    else "stdout · stderr · figures",
                    color = TextFaint,
                    fontSize = 10.sp
                )
            }
            IconButton(
                onClick = {
                    val text = vm.outputItems.joinToString("\n") { item ->
                        when (item) {
                            is OutputItem.Text -> item.text
                            is OutputItem.Note -> "— ${item.text} —"
                            is OutputItem.Image -> "[image: ${item.label}]"
                        }
                    }.trim()
                    clipboard.setText(AnnotatedString(text))
                    copyPulse++
                },
                enabled = vm.outputItems.isNotEmpty()
            ) {
                Icon(Icons.Rounded.ContentCopy, "Copy output", tint = TextSecondary, modifier = Modifier.size(18.dp))
            }
            IconButton(onClick = vm::clearOutput, enabled = vm.outputItems.isNotEmpty()) {
                Icon(Icons.Rounded.DeleteSweep, "Clear output", tint = TextSecondary, modifier = Modifier.size(19.dp))
            }
        }
        if (vm.isRunning) {
            LinearProgressIndicator(
                modifier = Modifier.fillMaxWidth().height(2.dp),
                color = Lime,
                trackColor = SurfaceHigh
            )
        } else {
            Box(Modifier.fillMaxWidth().height(1.dp).background(BorderSoft))
        }

        if (vm.outputItems.isEmpty()) {
            EmptyOutput(onRun = vm::runCurrent)
        } else {
            LazyColumn(
                state = listState,
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(vm.outputItems) { item ->
                    when (item) {
                        is OutputItem.Note -> NoteRow(item.text)
                        is OutputItem.Text -> TextResult(item)
                        is OutputItem.Image -> ImageResult(item) { previewImage = item }
                    }
                }
                item {
                    if (vm.isRunning) {
                        Row(
                            modifier = Modifier.padding(vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            CircularProgressIndicator(Modifier.size(12.dp), color = Lime, strokeWidth = 1.5.dp)
                            Spacer(Modifier.width(7.dp))
                            Text("Process is running…", color = TextFaint, fontSize = 10.5.sp)
                        }
                    }
                }
            }
        }
    }

    previewImage?.let { image ->
        Dialog(
            onDismissRequest = { previewImage = null },
            properties = DialogProperties(usePlatformDefaultWidth = false)
        ) {
            Column(
                Modifier
                    .fillMaxSize()
                    .background(Color(0xFF050706))
                    .padding(12.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        image.label,
                        color = TextPrimary,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 12.sp,
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(onClick = { previewImage = null }) {
                        Icon(Icons.Rounded.Close, "Close preview", tint = TextPrimary)
                    }
                }
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    val bitmap = remember(image.path) { decodeImage(image.path) }
                    if (bitmap != null) {
                        Image(
                            bitmap = bitmap,
                            contentDescription = image.label,
                            contentScale = ContentScale.Fit,
                            modifier = Modifier.fillMaxWidth()
                        )
                    } else {
                        Text("Image could not be decoded", color = Coral)
                    }
                }
            }
        }
    }
}

@Composable
private fun EmptyOutput(onRun: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize().padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .size(64.dp)
                .clip(RoundedCornerShape(18.dp))
                .background(SurfaceRaised),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Rounded.PhotoLibrary, null, tint = Lime, modifier = Modifier.size(28.dp))
        }
        Spacer(Modifier.height(16.dp))
        Text("Your output gets its own space", color = TextPrimary, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
        Spacer(Modifier.height(6.dp))
        Text(
            "Print statements, tracebacks and rendered figures all appear here — never squeezed under the editor.",
            color = TextFaint,
            fontSize = 11.5.sp,
            lineHeight = 18.sp
        )
        Spacer(Modifier.height(18.dp))
        Surface(
            color = LimeDeep,
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier.clip(RoundedCornerShape(10.dp)).clickable(onClick = onRun)
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 14.dp, vertical = 9.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Rounded.PlayArrow, null, tint = Lime, modifier = Modifier.size(17.dp))
                Spacer(Modifier.width(5.dp))
                Text("Run current file", color = Lime, fontSize = 11.5.sp, fontWeight = FontWeight.SemiBold)
            }
        }
        Spacer(Modifier.height(14.dp))
        Text("plt.show() and cv2.imshow() render in this tab", color = TextFaint, fontSize = 9.5.sp)
    }
}

@Composable
private fun NoteRow(text: String) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(top = 3.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(4.dp).clip(CircleShape).background(TextFaint))
        Spacer(Modifier.width(7.dp))
        Text(
            text.uppercase(),
            color = TextFaint,
            fontSize = 8.5.sp,
            fontFamily = FontFamily.Monospace,
            letterSpacing = 0.5.sp
        )
        Spacer(Modifier.width(9.dp))
        Box(Modifier.weight(1f).height(1.dp).background(BorderSoft))
    }
}

@Composable
private fun TextResult(item: OutputItem.Text) {
    val isError = item.stream == OutputStream.STDERR
    Surface(
        color = if (isError) Color(0xFF1B1110) else Surface,
        shape = RoundedCornerShape(9.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row {
            Box(
                Modifier
                    .width(2.dp)
                    .heightIn(min = 38.dp)
                    .background(if (isError) Coral else Lime)
            ) {}
            SelectionContainer {
                Text(
                    text = item.text.trimEnd('\n').ifEmpty { " " },
                    color = if (isError) Color(0xFFFFB4AD) else Color(0xFFDCE7DE),
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.5.sp,
                    lineHeight = 17.5.sp,
                    modifier = Modifier.padding(horizontal = 11.dp, vertical = 9.dp)
                )
            }
        }
    }
}

@Composable
private fun ImageResult(item: OutputItem.Image, onOpen: () -> Unit) {
    val bitmap = remember(item.path) { decodeImage(item.path) }
    Surface(color = SurfaceRaised, shape = RoundedCornerShape(10.dp), modifier = Modifier.fillMaxWidth()) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    Modifier.size(24.dp).clip(RoundedCornerShape(6.dp)).background(Color(0xFF24351D)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Rounded.PhotoLibrary, null, tint = Lime, modifier = Modifier.size(14.dp))
                }
                Spacer(Modifier.width(8.dp))
                Column(Modifier.weight(1f)) {
                    Text("Rendered figure", color = TextPrimary, fontSize = 11.sp, fontWeight = FontWeight.Medium)
                    Text(item.label, color = TextFaint, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                }
                if (bitmap != null) {
                    Text(
                        "${bitmap.width}×${bitmap.height}",
                        color = TextFaint,
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
            if (bitmap != null) {
                Image(
                    bitmap = bitmap,
                    contentDescription = item.label,
                    contentScale = ContentScale.Fit,
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 120.dp, max = 380.dp)
                        .clip(RoundedCornerShape(bottomStart = 10.dp, bottomEnd = 10.dp))
                        .background(Color(0xFF0B100D))
                        .clickable(onClick = onOpen)
                )
            } else {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Rounded.ErrorOutline, null, tint = Coral, modifier = Modifier.size(15.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("The image was not written to disk.", color = TextSecondary, fontSize = 10.5.sp)
                }
            }
        }
    }
}

private fun decodeImage(path: String) = runCatching {
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeFile(path, bounds)
    var sample = 1
    while (max(bounds.outWidth, bounds.outHeight) / sample > 1800) sample *= 2
    val options = BitmapFactory.Options().apply { inSampleSize = sample }
    BitmapFactory.decodeFile(path, options)?.asImageBitmap()
}.getOrNull()
