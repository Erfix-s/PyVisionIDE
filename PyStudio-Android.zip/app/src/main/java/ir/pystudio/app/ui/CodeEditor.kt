package ir.pystudio.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ir.pystudio.app.StudioViewModel
import ir.pystudio.app.ui.theme.Amber
import ir.pystudio.app.ui.theme.Coral
import ir.pystudio.app.ui.theme.Ink
import ir.pystudio.app.ui.theme.Lime
import ir.pystudio.app.ui.theme.Sky
import ir.pystudio.app.ui.theme.TextFaint
import ir.pystudio.app.ui.theme.TextPrimary

private val EditorStyle = TextStyle(
    fontFamily = FontFamily.Monospace,
    fontSize = 13.sp,
    lineHeight = 21.sp,
    color = TextPrimary
)

private val SyntaxRegex = Regex(
    """(\#[^\n]*)|("{3}[\s\S]*?"{3}|'{3}[\s\S]*?'{3}|"(?:\\.|[^"\\\n])*"|'(?:\\.|[^'\\\n])*')|(@[A-Za-z_][\w.]*)|\b(def|class|import|from|as|if|elif|else|for|while|return|in|not|and|or|is|None|True|False|try|except|finally|with|lambda|yield|async|await|pass|break|continue|global|nonlocal|assert|del|raise|match|case)\b|\b(print|len|range|enumerate|zip|list|dict|set|tuple|int|float|str|bool|open|input|type|super|isinstance|sorted|min|max|sum|abs|round|map|filter)\b|\b(\d+(?:\.\d+)?(?:e[+-]?\d+)?)\b""",
    RegexOption.IGNORE_CASE
)

@Composable
fun StudioCodeEditor(vm: StudioViewModel, modifier: Modifier = Modifier) {
    val scroll = rememberScrollState()
    val lineCount = vm.buffer.count { it == '\n' } + 1
    val value = TextFieldValue(text = vm.buffer, selection = vm.selection)

    Row(
        modifier = modifier
            .fillMaxSize()
            .background(Ink)
            .verticalScroll(scroll)
    ) {
        Column(
            modifier = Modifier
                .width(46.dp)
                .padding(top = 14.dp, bottom = 80.dp, start = 8.dp, end = 7.dp),
            horizontalAlignment = androidx.compose.ui.Alignment.End
        ) {
            for (line in 1..lineCount) {
                val active = line == currentLine(vm)
                Text(
                    text = line.toString(),
                    color = if (active) Lime else TextFaint,
                    fontSize = 12.sp,
                    lineHeight = 21.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = if (active) FontWeight.Bold else FontWeight.Normal
                )
            }
        }
        Box(
            modifier = Modifier
                .width(1.dp)
                .padding(top = 12.dp, bottom = 40.dp)
                .background(Color(0xFF1E2821))
        ) {}
        BasicTextField(
            value = value,
            onValueChange = { next ->
                if (next.text != vm.buffer) vm.dirty = true
                vm.buffer = next.text
                vm.selection = next.selection
            },
            modifier = Modifier
                .weight(1f)
                .padding(start = 11.dp, end = 12.dp, top = 14.dp, bottom = 80.dp),
            textStyle = EditorStyle,
            cursorBrush = SolidColor(Lime),
            visualTransformation = remember { PythonHighlightTransformation() },
            keyboardOptions = KeyboardOptions(
                capitalization = KeyboardCapitalization.None,
                autoCorrect = false,
                keyboardType = KeyboardType.Text
            ),
            decorationBox = { inner ->
                Box(Modifier.fillMaxWidth()) {
                    if (vm.buffer.isEmpty()) {
                        Text(
                            "# Start typing Python…",
                            style = EditorStyle,
                            color = TextFaint
                        )
                    }
                    inner()
                }
            }
        )
    }
}

private fun currentLine(vm: StudioViewModel): Int {
    val cursor = vm.selection.start.coerceIn(0, vm.buffer.length)
    return vm.buffer.substring(0, cursor).count { it == '\n' } + 1
}

private class PythonHighlightTransformation : VisualTransformation {
    override fun filter(text: AnnotatedString): TransformedText {
        val source = text.text
        val highlighted = buildAnnotatedString {
            append(source)
            SyntaxRegex.findAll(source).forEach { match ->
                val (color, italic, bold) = when {
                    match.groups[1] != null -> Triple(TextFaint, true, false)
                    match.groups[2] != null -> Triple(Color(0xFFA8D8A0), false, false)
                    match.groups[3] != null -> Triple(Amber, false, false)
                    match.groups[4] != null -> Triple(Coral, false, true)
                    match.groups[5] != null -> Triple(Sky, false, false)
                    else -> Triple(Color(0xFFD5B8FF), false, false)
                }
                addStyle(
                    SpanStyle(
                        color = color,
                        fontStyle = if (italic) FontStyle.Italic else FontStyle.Normal,
                        fontWeight = if (bold) FontWeight.Medium else FontWeight.Normal
                    ),
                    match.range.first,
                    (match.range.last + 1).coerceAtMost(source.length)
                )
            }
        }
        return TransformedText(highlighted, OffsetMapping.Identity)
    }
}
