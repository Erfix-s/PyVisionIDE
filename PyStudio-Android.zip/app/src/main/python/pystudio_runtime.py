"""
PyStudio's embedded Python runtime.

The Android UI passes a Java bridge object into run(). All standard output and
errors are forwarded to the Output tab, while matplotlib / OpenCV / Pillow
display calls are redirected to PNG files and rendered as images.
"""
import importlib
import io
import json
import os
import re
import sys
import traceback
import contextlib

_bridge = None
_workspace = None
_output_dir = None
_counter = 0
_patches_installed = False
_trace_events = 0


def _next_image_path(prefix):
    global _counter
    _counter += 1
    safe = re.sub(r"[^A-Za-z0-9_-]+", "_", prefix).strip("_") or "image"
    os.makedirs(_output_dir, exist_ok=True)
    return os.path.join(_output_dir, "%s_%03d.png" % (safe, _counter))


def _install_patches():
    """Patch display functions once, after the workspace is known."""
    global _patches_installed
    if _patches_installed:
        return
    _patches_installed = True

    # Matplotlib: make plt.show() produce a real PNG instead of a GUI window.
    try:
        import matplotlib
        matplotlib.use("Agg", force=True)
        import matplotlib.pyplot as plt

        def _show(*args, **kwargs):
            fig = plt.gcf()
            if not fig.get_axes():
                return
            path = _next_image_path("matplotlib")
            fig.savefig(path, dpi=160, bbox_inches="tight", facecolor=fig.get_facecolor())
            _bridge.image(path)
            if kwargs.get("block") is not None:
                pass
            plt.close(fig)

        plt.show = _show
    except Exception:
        pass

    # OpenCV: imshow() cannot open a native window from this screen, so save
    # the exact Mat to the Output tab. waitKey becomes a no-op.
    try:
        import cv2
        import numpy as np

        def _imshow(winname, mat):
            if mat is None:
                return
            path = _next_image_path("opencv")
            cv2.imwrite(path, np.asarray(mat))
            _bridge.image(path)

        cv2.imshow = _imshow
        cv2.waitKey = lambda *args, **kwargs: -1
        cv2.destroyAllWindows = lambda *args, **kwargs: None
        cv2.destroyWindow = lambda *args, **kwargs: None
    except Exception:
        pass

    # Pillow: Image.show() is redirected too.
    try:
        from PIL import Image

        def _pil_show(self, *args, **kwargs):
            path = _next_image_path("pillow")
            self.save(path, "PNG")
            _bridge.image(path)

        Image.Image.show = _pil_show
    except Exception:
        pass


def _tracer(frame, event, arg):
    global _trace_events
    if event == "line":
        _trace_events += 1
        if (_trace_events & 0x7FF) == 0 and _bridge is not None and _bridge.isCancelled():
            raise KeyboardInterrupt()
    return _tracer


def run(source, workspace, bridge):
    global _bridge, _workspace, _output_dir, _trace_events
    _bridge = bridge
    _workspace = workspace
    _output_dir = os.path.join(workspace, ".pystudio_output")
    _trace_events = 0
    os.makedirs(_output_dir, exist_ok=True)

    os.chdir(workspace)
    if workspace not in sys.path:
        sys.path.insert(0, workspace)

    _install_patches()

    namespace = {
        "__name__": "__main__",
        "__file__": os.path.join(workspace, ".pystudio_main.py"),
        "__builtins__": __builtins__,
    }

    class _BridgeStream(io.TextIOBase):
        def __init__(self, is_error):
            self.is_error = is_error

        def write(self, text):
            if not isinstance(text, str):
                text = str(text)
            if text:
                if self.is_error:
                    _bridge.error(text)
                else:
                    _bridge.write(text)
            return len(text)

        def flush(self):
            return None

    sys.settrace(_tracer)
    try:
        code = compile(source, "<PyStudio>", "exec")
        with contextlib.redirect_stdout(_BridgeStream(False)), contextlib.redirect_stderr(_BridgeStream(True)):
            exec(code, namespace, namespace)
    except KeyboardInterrupt:
        _bridge.write("\nExecution stopped by user.\n")
    except SystemExit as exit_error:
        if exit_error.code not in (None, 0):
            _bridge.error("\nSystemExit: %s\n" % exit_error.code)
    except BaseException:
        _bridge.error("\n" + traceback.format_exc(limit=12))
    finally:
        sys.settrace(None)
        _bridge.write("\n")


def versions():
    """Return bundled package versions as JSON; imported lazily by Libraries."""
    modules = {
        "numpy": "numpy",
        "matplotlib": "matplotlib",
        "cv2": "OpenCV",
        "PIL": "Pillow",
        "pandas": "pandas",
        "requests": "Requests",
    }
    result = {}
    for module_name, display_name in modules.items():
        try:
            module = importlib.import_module(module_name)
            result[display_name] = getattr(module, "__version__", "bundled")
        except Exception:
            pass
    return json.dumps(result)
