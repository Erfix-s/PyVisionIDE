# Chaquopy and Compose already ship consumer rules. Keep Python bridge method
# names stable for reflective calls originating in Python.
-keep class ir.pystudio.app.python.PythonBridge { public *; }
-keep class ir.pystudio.app.python.PythonRunner { *; }
