# PyStudio — on-device Python IDE for Android

PyStudio is a native Android (Kotlin + Jetpack Compose) Python editor, runner, shell and
output viewer. CPython runs on the device through [Chaquopy](https://chaquo.com/chaquopy/).
Native wheels (NumPy, OpenCV, Matplotlib, Pillow, pandas, Requests) are resolved and copied
into the APK by Gradle at build time, so ordinary `import` statements work offline.

## Build

Requirements: JDK 17, Android SDK 35, Python **3.10** on `PATH` (Chaquopy's build interpreter).

```bash
gradle assembleRelease
```

The workflow in `.github/workflows/build.yml` installs all of these, exports a monotonically
increasing version from `GITHUB_RUN_NUMBER`, signs the APK with the fixed keystore, and publishes
a GitHub Release. Do not move `keystore/pystudio-release.p12` or `keystore.properties`: both must
stay inside the project ZIP.

## Seamless upgrades

- `applicationId` is permanently `ir.pystudio.app`.
- Every run gets `versionCode = 1000 + GITHUB_RUN_NUMBER`.
- Every APK is signed with the same included PKCS#12 key.
- Installing a newer release over an older one keeps all workspace files.

Changing the applicationId or replacing the keystore breaks update compatibility. The committed
key is deliberate for a public, no-secrets workflow; treat it as a project key, not a private one.

## App structure

| Area | Location |
| --- | --- |
| Compose UI / tabs | `app/src/main/java/ir/pystudio/app/ui` |
| Editor state, run orchestration, file picker insertion | `StudioViewModel.kt` |
| Workspace + SAF import bridge | `data/WorkspaceRepository.kt` |
| Chaquopy bridge | `python/PythonRunner.kt` |
| Output capture, `plt.show`, `cv2.imshow`, Pillow `show` | `app/src/main/python/pystudio_runtime.py` |
| Linux-style command parser | `shell/ShellSession.kt` |
| Samples | `app/src/main/assets/samples` |

## File access

Android's Storage Access Framework returns `content://` URIs, not filesystem paths. NumPy,
OpenCV and Pillow need real paths, so the **Insert file** button copies the selected file into
`files/workspace/imports/` and inserts that absolute path at the cursor. If the cursor is inside
a call such as `cv2.imread(|)`, a comma is inserted automatically. Any MIME type is accepted.

## Honest Android limitations

- **`pip install` at runtime is not possible.** Chaquopy has no in-app compiler or package
  installer. PyStudio implements `pip list` and explains exactly how to bundle a requested package;
  native packages are installed during the CI build and signed into the APK.
- **GUI windows cannot be opened by Python.** `plt.show()`, `cv2.imshow()` and Pillow `show()` are
  redirected to PNGs and displayed in the separate Output tab. `cv2.waitKey()` is a no-op.
- **`input()` has no stdin stream** because this is an editor, not a terminal emulator. Read files
  or constants instead; an input dialog would require a custom Python stdin bridge.
- Long-running native calls may ignore Stop. The cooperative Python tracer stops pure-Python loops,
  but a call already inside a native library must finish (Android has no safe process-wide Python
  interrupt).
- Libraries must have an Android wheel in Chaquopy's repository. If a wheel is unavailable for the
  selected Python/ABI, Gradle fails clearly instead of shipping a broken import.
- The universal APK is large because NumPy, OpenCV, Matplotlib and pandas contain native ABIs.
  Only `arm64-v8a` and `armeabi-v7a` are shipped. Emulator x86_64 users can add that ABI locally.
