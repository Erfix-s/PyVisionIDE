package com.pystudio.app

import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import java.io.File

/** Terminal lines. */
class TerminalAdapter(
    private val items: MutableList<OutputEvent>
) : RecyclerView.Adapter<TerminalAdapter.LineVH>() {

    class LineVH(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val text: TextView = itemView.findViewById(R.id.terminalLine)
    }

    companion object {
        private const val MAX_LINES = 600
        private val COLOR_OUT = Color.parseColor("#D8E3EE")
        private val COLOR_ERR = Color.parseColor("#FF6B6B")
        private val COLOR_INFO = Color.parseColor("#7C9EFF")
        private val COLOR_OK = Color.parseColor("#3DDC97")
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): LineVH {
        val v = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_terminal_line, parent, false)
        return LineVH(v)
    }

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(holder: LineVH, position: Int) {
        val e = items[position]
        holder.text.text = e.text
        holder.text.setTextColor(
            when (e.kind) {
                OutputEvent.Kind.TERM_ERR, OutputEvent.Kind.STDERR -> COLOR_ERR
                OutputEvent.Kind.TERM_INFO, OutputEvent.Kind.INFO -> COLOR_INFO
                OutputEvent.Kind.STDOUT -> COLOR_OK
                else -> COLOR_OUT
            }
        )
    }

    fun append(event: OutputEvent) {
        val last = items.lastOrNull()
        if (last != null && last.kind == event.kind && event.kind != OutputEvent.Kind.TERM_INFO) {
            items[items.size - 1] = last.copy(text = (last.text + event.text).takeLast(8000))
            notifyItemChanged(items.size - 1)
        } else {
            items.add(event)
            notifyItemInserted(items.size - 1)
        }
        while (items.size > MAX_LINES) {
            items.removeAt(0)
            notifyItemRemoved(0)
        }
    }

    fun clear() {
        items.clear()
        notifyDataSetChanged()
    }
}

/** Generic list of files used by the "open file" and "insert path" dialogs. */
class FileAdapter(
    private val files: MutableList<File>,
    private val onClick: (File) -> Unit,
    private val onLongClick: ((File) -> Boolean)? = null
) : RecyclerView.Adapter<FileAdapter.FileVH>() {

    class FileVH(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val icon: ImageView = itemView.findViewById(R.id.fileIcon)
        val name: TextView = itemView.findViewById(R.id.fileName)
        val meta: TextView = itemView.findViewById(R.id.fileMeta)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FileVH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_file, parent, false)
        return FileVH(v)
    }

    override fun getItemCount(): Int = files.size

    override fun onBindViewHolder(holder: FileVH, position: Int) {
        val f = files[position]
        holder.name.text = if (f.isDirectory) "${f.name}/" else f.name
        holder.meta.text = if (f.isDirectory) {
            "dir"
        } else {
            "${f.length() / 1024} KB"
        }
        holder.icon.setImageResource(
            when {
                f.isDirectory -> R.drawable.ic_folder
                f.extension == "py" -> R.drawable.ic_code
                else -> R.drawable.ic_insert_file
            }
        )
        holder.icon.setColorFilter(Color.parseColor(if (f.isDirectory) "#7C9EFF" else "#3DDC97"))
        holder.itemView.setOnClickListener { onClick(f) }
        holder.itemView.setOnLongClickListener {
            onLongClick?.invoke(f) ?: false
        }
    }

    fun submit(list: List<File>) {
        files.clear()
        files.addAll(list)
        notifyDataSetChanged()
    }
}
