package com.pystudio.app

import android.app.Application
import java.io.File
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * Application entry point.
 *
 * Python (CPython, provided by Chaquopy) is started as early as possible on a
 * background thread so the first `Run` feels instant.
 */
class PyStudioApp : Application() {

    companion object {
        @Volatile
        var pythonReady: Boolean = false
            private set

        private val readyLatch = CountDownLatch(1)

        /** Blocks until the interpreter is started (max 20s). */
        fun awaitPython(): Boolean =
            if (pythonReady) true else readyLatch.await(20, TimeUnit.SECONDS)
    }

    override fun onCreate() {
        super.onCreate()
        FileManager.init(this)

        Thread {
            try {
                PythonEngine.start(this)
                pythonReady = true
            } catch (t: Throwable) {
                OutputBus.post(
                    OutputEvent(
                        OutputEvent.Kind.TERM_ERR,
                        "[PyStudio] Python failed to start: ${t.message}\n"
                    )
                )
            } finally {
                readyLatch.countDown()
            }
        }.start()

        // Make sure the default project files exist (sample scripts).
        try {
            val project = File(FileManager.projectDir)
            if (!project.exists()) project.mkdirs()
            FileManager.writeDefaultSamples()
        } catch (_: Throwable) {
        }
    }
}
