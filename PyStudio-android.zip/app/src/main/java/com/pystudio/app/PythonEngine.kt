package com.pystudio.app

import android.content.Context
import com.chaquo.python.PyException
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Thin Kotlin wrapper around the Chaquopy interpreter.
 *
 * All the heavy lifting (stdout redirect, matplotlib / cv2 / PIL patching,
 * traceback cleanup, pip) lives in `src/main/python/pystudio_runner.py`.
 */
object PythonEngine {

    private val bridge = OutputBridge()
    private val running = AtomicBoolean(false)
    private var runner: com.chaquo.python.PyObject? = null

    @Volatile
    private var workThread: Thread? = null

    fun start(context: Context) {
        if (!Python.isStarted()) {
            Python.start(AndroidPlatform(context))
        }
        val py = Python.getInstance()
        runner = py.getModule("pystudio_runner")

        val siteDir = File(context.cacheDir, "site-packages").apply { mkdirs() }
        runner?.callAttr(
            "setup",
            bridge,
            context.filesDir.absolutePath,
            context.cacheDir.absolutePath,
            FileManager.projectDir,
            siteDir.absolutePath
        )
        OutputBus.post(
            OutputEvent(OutputEvent.Kind.TERM_INFO, "[PyStudio] Python " + pyVersion() + " ready\n")
        )
    }

    fun isRunning(): Boolean = running.get()

    /** Python version string, used in the About box and the console banner. */
    fun versionSafe(): String = try {
        runner?.callAttr("python_version")?.toString() ?: "3.x"
    } catch (_: Throwable) {
        "3.x"
    }

    fun submitInput(value: String) = bridge.submitInput(value)

    fun releaseInput() = bridge.releaseInput()

    fun sitePackagesDir(context: Context): File =
        File(context.cacheDir, "site-packages").apply { mkdirs() }

    private fun pyVersion(): String = try {
        runner?.callAttr("python_version")?.toString() ?: "3"
    } catch (_: Throwable) {
        "3"
    }

    /** Ask the running script to stop (cooperative interrupt, see the runner). */
    fun requestStop() {
        try {
            runner?.callAttr("request_stop")
        } catch (_: Throwable) {
        }
    }

    /** Hard stop: kills the thread that executes Python (last resort). */
    fun hardStop() {
        requestStop()
        val t = workThread
        if (t != null && t.isAlive) {
            try {
                t.interrupt()
            } catch (_: Throwable) {
            }
        }
    }

    // ------------------------------------------------------------------ run ---
    fun runScript(
        source: String,
        scriptPath: String,
        workDir: String,
        args: List<String>,
        sink: OutputBus.Sink,
        onStarted: () -> Unit,
        onFinished: (Boolean) -> Unit
    ): Boolean {
        if (running.get()) return false
        if (!PyStudioApp.awaitPython()) {
            OutputBus.post(
                OutputEvent(OutputEvent.Kind.ERROR, "Python engine is still starting, try again.")
            )
            onFinished(false)
            return false
        }
        running.set(true)
        OutputBus.sink = sink
        onStarted()
        workThread = Thread {
            try {
                runner?.callAttr("run_script", source, scriptPath, workDir, args)
            } catch (e: PyException) {
                OutputBus.post(OutputEvent(OutputEvent.Kind.ERROR, e.message ?: e.toString()))
                OutputBus.post(OutputEvent(OutputEvent.Kind.DONE, "error"))
            } catch (t: Throwable) {
                OutputBus.post(
                    OutputEvent(OutputEvent.Kind.ERROR, "Runtime error: ${t.message ?: t}")
                )
                OutputBus.post(OutputEvent(OutputEvent.Kind.DONE, "error"))
            } finally {
                running.set(false)
                onFinished(true)
            }
        }.also { it.start() }
        return true
    }

    /** One line of the interactive REPL (`python` with no file argument). */
    fun runLine(source: String, workDir: String, sink: OutputBus.Sink) {
        if (!PyStudioApp.awaitPython()) return
        OutputBus.sink = sink
        workThread = Thread {
            try {
                runner?.callAttr("run_line", source, workDir)
            } catch (e: PyException) {
                OutputBus.post(OutputEvent(OutputEvent.Kind.TERM_ERR, (e.message ?: "") + "\n"))
            } catch (t: Throwable) {
                OutputBus.post(OutputEvent(OutputEvent.Kind.TERM_ERR, "${t.message ?: t}\n"))
            }
        }.also { it.start() }
    }

    // ------------------------------------------------------------------ pip ---
    fun pip(args: List<String>, context: Context) {
        if (!PyStudioApp.awaitPython()) return
        OutputBus.sink = OutputBus.Sink.TERMINAL
        workThread = Thread {
            try {
                runner?.callAttr("pip_command", args, sitePackagesDir(context).absolutePath)
            } catch (e: PyException) {
                OutputBus.post(OutputEvent(OutputEvent.Kind.TERM_ERR, (e.message ?: "") + "\n"))
            } catch (t: Throwable) {
                OutputBus.post(OutputEvent(OutputEvent.Kind.TERM_ERR, "${t.message ?: t}\n"))
            }
        }.also { it.start() }
    }
}
