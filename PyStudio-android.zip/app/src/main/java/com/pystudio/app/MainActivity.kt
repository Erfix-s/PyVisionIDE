package com.pystudio.app

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.widget.EditText
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.bottomnavigation.BottomNavigationView
import java.io.File
import java.text.SimpleDateFormat
import java.util.ArrayDeque
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    // ------------------------------------------------------------ views ---
    private lateinit var toolbar: MaterialToolbar
    private lateinit var bottomNav: BottomNavigationView

    private lateinit var codeEditor: EditText
    private lateinit var gutter: LineNumberView
    private lateinit var cursorLabel: TextView
    private lateinit var fileStatusLabel: TextView
    private lateinit var btnRun: TextView
    private lateinit var btnStop: ImageButton
    private lateinit var chipInsertPath: TextView
    private lateinit var chipOpen: TextView
    private lateinit var chipSave: TextView
    private lateinit var chipNewFile: TextView
    private lateinit var chipUndo: TextView
    private lateinit var chipRedo: TextView

    private lateinit var outputList: RecyclerView
    private lateinit var outputEmpty: TextView
    private lateinit var outputStatus: TextView
    private lateinit var inputRow: View
    private lateinit var inputPrompt: TextView
    private lateinit var inputField: EditText
    private lateinit var btnSendInput: ImageButton
    private lateinit var btnClearOutput: ImageButton
    private lateinit var btnCopyOutput: ImageButton

    private lateinit var terminalList: RecyclerView
    private lateinit var terminalInput: EditText
    private lateinit var btnSendCommand: ImageButton
    private lateinit var chipPip: TextView
    private lateinit var chipLs: TextView
    private lateinit var chipPython: TextView
    private lateinit var chipHelp: TextView

    private lateinit var outputAdapter: OutputAdapter
    private lateinit var terminalAdapter: TerminalAdapter
    private lateinit var filesAdapter: FileAdapter
    private lateinit var pickAdapter: FileAdapter

    private val outputItems = mutableListOf<OutputEvent>()
    private val terminalItems = mutableListOf<OutputEvent>()
    private val filesItems = mutableListOf<File>()
    private val pickItems = mutableListOf<File>()

    private val outputLayoutManager = LinearLayoutManager(this)
    private val terminalLayoutManager = LinearLayoutManager(this)
    private val filesLayoutManager = LinearLayoutManager(this)
    private val pickLayoutManager = LinearLayoutManager(this)

    // ------------------------------------------------------------ state ---
    private lateinit var highlighter: PythonHighlighter
    private val main = Handler(Looper.getMainLooper())

    private var currentFile: File? = null
    private var dirty = false
    private var replActive = false
    private var runStartTime = 0L
    private var highlightPending = false
    private var pendingIndentPos = -1
    private var tickerRunnable: Runnable? = null
    private var pickDir: File? = null
    private var filesDirCurrent: File? = null
    private var filesMode: FilesMode = FilesMode.OPEN

    private var filesDialog: AlertDialog? = null
    private var pickDialog: AlertDialog? = null

    private val undoStack = ArrayDeque<Pair<String, Int>>()
    private val redoStack = ArrayDeque<Pair<String, Int>>()
    private var lastEditAt = 0L

    private enum class Pane { EDITOR, OUTPUT, TERMINAL }
    private enum class FilesMode { OPEN, SAVE_AS }

    private var pane = Pane.EDITOR
    private lateinit var paneEditor: View
    private lateinit var paneOutput: View
    private lateinit var paneTerminal: View

    // ========================================================== onCreate ===
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        highlighter = PythonHighlighter(this)

        bindViews()
        setupEditor()
        setupToolbar()
        setupBottomNav()
        setupOutputPane()
        setupTerminalPane()

        OutputBus.subscribe(::onOutputEvent)

        FileManager.ensureDirs()

        val saved = getPreferences(MODE_PRIVATE).getString(KEY_LAST_FILE, null)
        currentFile = when {
            saved != null && File(saved).exists() -> File(saved)
            else -> File(FileManager.projectDir, "main.py")
        }
        if (!currentFile!!.exists()) {
            FileManager.writeText(currentFile!!, "")
        }
        loadFile(currentFile!!)

        maybeAskForStorage()

        terminalAdapter.append(
            OutputEvent(OutputEvent.Kind.TERM_INFO, getString(R.string.terminal_welcome) + "\n\n")
        )

        main.postDelayed(cursorTask, 250)
    }

    private val cursorTask = object : Runnable {
        override fun run() {
            updateCursorLabels()
            main.postDelayed(this, 250)
        }
    }

    private fun bindViews() {
        toolbar = findViewById(R.id.toolbar)
        bottomNav = findViewById(R.id.bottomNav)
        paneEditor = findViewById(R.id.editorPaneRoot)
        paneOutput = findViewById(R.id.outputPaneRoot)
        paneTerminal = findViewById(R.id.terminalPaneRoot)

        codeEditor = findViewById(R.id.codeEditor)
        gutter = findViewById(R.id.gutter)
        cursorLabel = findViewById(R.id.cursorLabel)
        fileStatusLabel = findViewById(R.id.fileStatusLabel)
        btnRun = findViewById(R.id.btnRun)
        btnStop = findViewById(R.id.btnStop)
        chipInsertPath = findViewById(R.id.chipInsertPath)
        chipOpen = findViewById(R.id.chipOpen)
        chipSave = findViewById(R.id.chipSave)
        chipNewFile = findViewById(R.id.chipNewFile)
        chipUndo = findViewById(R.id.chipUndo)
        chipRedo = findViewById(R.id.chipRedo)

        outputList = findViewById(R.id.outputList)
        outputEmpty = findViewById(R.id.outputEmpty)
        outputStatus = findViewById(R.id.outputStatus)
        inputRow = findViewById(R.id.inputRow)
        inputPrompt = findViewById(R.id.inputPrompt)
        inputField = findViewById(R.id.inputField)
        btnSendInput = findViewById(R.id.btnSendInput)
        btnClearOutput = findViewById(R.id.btnClearOutput)
        btnCopyOutput = findViewById(R.id.btnCopyOutput)

        terminalList = findViewById(R.id.terminalList)
        terminalInput = findViewById(R.id.terminalInput)
        btnSendCommand = findViewById(R.id.btnSendCommand)
        chipPip = findViewById(R.id.chipPip)
        chipLs = findViewById(R.id.chipLs)
        chipPython = findViewById(R.id.chipPython)
        chipHelp = findViewById(R.id.chipHelp)
    }

    // =========================================================== editor ====
    @SuppressLint("SetTextI18n")
    private fun setupEditor() {
        gutter.attach(codeEditor)
        outputList.layoutManager = outputLayoutManager
        outputAdapter = OutputAdapter(outputItems) { bytes, name -> saveImage(bytes, name) }
        outputList.adapter = outputAdapter

        codeEditor.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
                // Snapshot for undo at the beginning of every typing burst.
                val now = System.currentTimeMillis()
                if (now - lastEditAt > 700) {
                    undoStack.addLast(s.toString() to codeEditor.selectionStart)
                    if (undoStack.size > 100) undoStack.removeFirst()
                    redoStack.clear()
                }
            }

            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                if (before == 0 && count == 1 && start in 0 until s.length && s[start] == '\n') {
                    pendingIndentPos = start
                }
            }

            override fun afterTextChanged(s: Editable) {
                if (pendingIndentPos >= 0) {
                    val pos = pendingIndentPos
                    pendingIndentPos = -1
                    applyAutoIndent(pos)
                }
                lastEditAt = System.currentTimeMillis()
                dirty = true
                refreshFileStatus()
                gutter.refresh()
                scheduleHighlight()
            }
        })

        btnRun.setOnClickListener { runCode() }
        btnStop.setOnClickListener { stopCode() }
        chipInsertPath.setOnClickListener { insertFilePath() }
        chipOpen.setOnClickListener { showFilesDialog(FilesMode.OPEN) }
        chipSave.setOnClickListener { saveCurrent(true) }
        chipNewFile.setOnClickListener { newFilePrompt() }
        chipUndo.setOnClickListener { undo() }
        chipRedo.setOnClickListener { redo() }
        findViewById<TextView>(R.id.chipClearEditor).setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle(R.string.clear_editor)
                .setMessage(R.string.clear_editor)
                .setPositiveButton(R.string.ok) { _, _ ->
                    codeEditor.setText("")
                    scheduleHighlight()
                }
                .setNegativeButton(R.string.cancel, null)
                .show()
        }
    }

    private fun scheduleHighlight() {
        if (highlightPending) return
        highlightPending = true
        Thread {
            val text = codeEditor.text?.toString() ?: ""
            val tokens = highlighter.scan(text)
            main.post {
                highlightPending = false
                val editable = codeEditor.editableText
                if (editable != null && editable.toString() == text) {
                    highlighter.apply(editable, tokens)
                }
            }
        }.start()
    }

    /**
     * Called right after a newline was typed: copies the indentation of the
     * previous line and adds one level when the line ends with ':'.
     */
    private fun applyAutoIndent(newLinePos: Int) {
        val text = codeEditor.text ?: return
        if (newLinePos < 0 || newLinePos >= text.length) return
        val lineStart = text.lastIndexOf('\n', (newLinePos - 1).coerceAtLeast(0)).let {
            if (it < 0) 0 else it + 1
        }
        if (lineStart > newLinePos) return
        val line = text.substring(lineStart, newLinePos)
        val indent = line.takeWhile { it == ' ' || it == '\t' }
        val extra = if (line.trimEnd().endsWith(":")) "    " else ""
        if (indent.isEmpty() && extra.isEmpty()) return
        val insert = indent + extra
        text.insert(newLinePos + 1, insert)
        codeEditor.setSelection(newLinePos + 1 + insert.length)
    }

    private fun updateCursorLabels() {
        val text = codeEditor.text ?: return
        val sel = codeEditor.selectionStart.coerceAtLeast(0)
        val layout = codeEditor.layout ?: return
        val line = layout.getLineForOffset(sel.coerceAtMost(text.length))
        val col = sel.coerceAtMost(text.length) - layout.getLineStart(line)
        cursorLabel.text = getString(R.string.cursor_position, line + 1, col + 1)
    }

    private fun refreshFileStatus() {
        val name = currentFile?.name ?: "untitled.py"
        fileStatusLabel.text = if (dirty) "$name •" else name
    }

    // ------------------------------------------------------------ history --
    private fun undo() {
        val snapshot = undoStack.pollLast() ?: run {
            Toast.makeText(this, "no undo entry", Toast.LENGTH_SHORT).show()
            return
        }
        val editable = codeEditor.editableText ?: return
        redoStack.addLast(editable.toString() to codeEditor.selectionEnd)
        editable.replace(0, editable.length, snapshot.first)
        codeEditor.setSelection(snapshot.second.coerceIn(0, editable.length))
        scheduleHighlight()
        gutter.refresh()
    }

    private fun redo() {
        val snapshot = redoStack.pollLast() ?: return
        val editable = codeEditor.editableText ?: return
        undoStack.addLast(editable.toString() to codeEditor.selectionEnd)
        editable.replace(0, editable.length, snapshot.first)
        codeEditor.setSelection(snapshot.second.coerceIn(0, editable.length))
        scheduleHighlight()
        gutter.refresh()
    }

    // ============================================================ files ====
    private fun loadFile(file: File) {
        currentFile = file
        val content = FileManager.readText(file)
        codeEditor.setText(content)
        codeEditor.setSelection(0)
        dirty = false
        refreshFileStatus()
        getPreferences(MODE_PRIVATE).edit().putString(KEY_LAST_FILE, file.absolutePath).apply()
        toolbar.subtitle = FileManager.prettyPath(file)
        gutter.refresh()
        scheduleHighlight()
    }

    private fun saveCurrent(showToast: Boolean): Boolean {
        val file = currentFile ?: File(FileManager.projectDir, "untitled.py")
        val ok = FileManager.writeText(file, codeEditor.text?.toString() ?: "")
        dirty = !ok
        refreshFileStatus()
        toolbar.subtitle = FileManager.prettyPath(file)
        if (ok && showToast) {
            Toast.makeText(
                this,
                getString(R.string.msg_saved_to, file.absolutePath),
                Toast.LENGTH_SHORT
            ).show()
        }
        return ok
    }

    private fun newFilePrompt() {
        promptDialog(getString(R.string.new_file_name), "script.py") { name ->
            val clean = if (name.endsWith(".py")) name else "$name.py"
            if (clean.isBlank()) return@promptDialog
            val file = File(FileManager.projectDir, clean)
            if (file.exists()) {
                loadFile(file)
            } else {
                FileManager.writeText(file, "# $clean\n\n")
                loadFile(file)
            }
        }
    }

    // ============================================================== run ====
    private fun runCode() {
        saveCurrent(false)
        val file = currentFile ?: return
        val source = codeEditor.text?.toString() ?: ""

        outputAdapter.clear()
        outputEmpty.visibility = View.GONE
        outputStatus.text = getString(R.string.output_running)

        val started = PythonEngine.runScript(
            source = source,
            scriptPath = file.absolutePath,
            workDir = FileManager.projectDir,
            args = emptyList(),
            sink = OutputBus.Sink.OUTPUT_TAB,
            onStarted = {
                runOnUiThread {
                    btnStop.isEnabled = true
                    btnRun.isEnabled = false
                    runStartTime = System.currentTimeMillis()
                    startTicker()
                }
            },
            onFinished = {
                runOnUiThread {
                    btnStop.isEnabled = false
                    btnRun.isEnabled = true
                    stopTicker()
                }
            }
        )
        if (started) showPane(Pane.OUTPUT)
    }

    private fun stopCode() {
        PythonEngine.requestStop()
        Toast.makeText(this, R.string.msg_stopped_by_user, Toast.LENGTH_SHORT).show()
    }

    private fun startTicker() {
        stopTicker()
        val task = object : Runnable {
            override fun run() {
                val seconds = (System.currentTimeMillis() - runStartTime) / 1000.0
                outputStatus.text =
                    getString(R.string.output_running) + "  " + formatSeconds(seconds)
                main.postDelayed(this, 250)
            }
        }
        tickerRunnable = task
        main.post(task)
    }

    private fun stopTicker() {
        tickerRunnable?.let { main.removeCallbacks(it) }
        tickerRunnable = null
    }

    private fun formatSeconds(seconds: Double): String =
        if (seconds < 60) "%.1fs".format(seconds)
        else "%d:%02d".format((seconds / 60).toInt(), (seconds % 60).toInt())

    // ============================================================ output ===
    private fun setupOutputPane() {
        btnClearOutput.setOnClickListener {
            outputAdapter.clear()
            outputEmpty.visibility = View.VISIBLE
            outputStatus.text = getString(R.string.output_cleared)
        }
        btnCopyOutput.setOnClickListener {
            val text = outputItems.joinToString("") { it.text }
            val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("PyStudio output", text))
            Toast.makeText(this, R.string.copy_output, Toast.LENGTH_SHORT).show()
        }
        btnSendInput.setOnClickListener { sendUserInput() }
        inputField.setOnEditorActionListener { _, _, event ->
            if (event?.keyCode == KeyEvent.KEYCODE_ENTER) {
                sendUserInput()
                true
            } else {
                false
            }
        }
    }

    private fun sendUserInput() {
        val value = inputField.text?.toString() ?: ""
        inputField.setText("")
        PythonEngine.submitInput(value)
        inputRow.visibility = View.GONE
    }

    private fun saveImage(bytes: ByteArray, name: String) {
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val base = (name.ifBlank { "figure" }).replace(Regex("\\s+"), "_")
        val file = FileManager.newOutputFile(stamp + "_" + base, "png")
        val ok = FileManager.writeBytes(file, bytes)
        Toast.makeText(
            this,
            if (ok) getString(R.string.msg_saved_to, file.absolutePath)
            else getString(R.string.msg_file_missing),
            Toast.LENGTH_SHORT
        ).show()
    }

    // ========================================================== terminal ===
    private fun setupTerminalPane() {
        terminalList.layoutManager = terminalLayoutManager
        terminalAdapter = TerminalAdapter(terminalItems)
        terminalList.adapter = terminalAdapter

        btnSendCommand.setOnClickListener { submitTerminalCommand() }
        terminalInput.setOnEditorActionListener { _, _, event ->
            if (event?.keyCode == KeyEvent.KEYCODE_ENTER) {
                submitTerminalCommand()
                true
            } else {
                false
            }
        }
        chipPip.setOnClickListener {
            terminalInput.setText("pip install ")
            terminalInput.setSelection(terminalInput.text?.length ?: 0)
            terminalInput.requestFocus()
        }
        chipLs.setOnClickListener { runCommand("ls") }
        chipPython.setOnClickListener { runCommand("python main.py") }
        chipHelp.setOnClickListener { runCommand("help") }
    }

    private fun submitTerminalCommand() {
        val text = terminalInput.text?.toString() ?: ""
        terminalInput.setText("")
        if (text.isBlank()) return
        runCommand(text)
    }

    private fun runCommand(command: String) {
        terminalAdapter.append(
            OutputEvent(
                OutputEvent.Kind.TERM_INFO,
                "${FileManager.projectDir}$ $command\n"
            )
        )
        executeCommand(command)
    }

    private fun executeCommand(raw: String) {
        val command = raw.trim()
        if (command.isEmpty()) return

        if (replActive) {
            if (command == "exit()" || command == "exit" || command == "quit") {
                replActive = false
                appendTermInfo("[PyStudio] console closed\n")
                return
            }
            PythonEngine.runLine(command, FileManager.projectDir, OutputBus.Sink.TERMINAL)
            return
        }

        val parts = tokenize(command)
        when (parts.firstOrNull()) {
            "help", "--help" -> appendTermInfo(HELP_TEXT)
            "clear" -> terminalAdapter.clear()
            "pwd" -> appendTermOut(FileManager.projectDir + "\n")
            "date" -> appendTermOut(
                SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date()) + "\n"
            )
            "cd" -> changeDirectory(parts.drop(1).joinToString(" "))
            "ls" -> listDirectory(resolvePath(parts.getOrNull(1)))
            "cat" -> catFile(resolvePath(parts.getOrNull(1)))
            "python", "python3", "py" -> runPython(parts.drop(1))
            "pip", "pip3" -> PythonEngine.pip(parts.drop(1), this)
            else -> shellCommand(command)
        }
    }

    private fun runPython(args: List<String>) {
        if (args.isEmpty()) {
            replActive = true
            appendTermInfo(
                "Python ${PythonEngine.versionSafe()} interactive console\n" +
                    "type python code line by line, `exit()` closes the console\n\n"
            )
            return
        }
        if (args.first() == "-c") {
            PythonEngine.runLine(
                args.drop(1).joinToString(" "),
                FileManager.projectDir,
                OutputBus.Sink.TERMINAL
            )
            return
        }
        val file = File(resolvePath(args.first()))
        if (!file.exists() || file.isDirectory) {
            appendTermErr("python: can't open file '${args.first()}': No such file\n")
            return
        }
        OutputBus.sink = OutputBus.Sink.TERMINAL
        PythonEngine.runScript(
            source = FileManager.readText(file),
            scriptPath = file.absolutePath,
            workDir = file.parent ?: FileManager.projectDir,
            args = args.drop(1),
            sink = OutputBus.Sink.TERMINAL,
            onStarted = {},
            onFinished = {}
        )
    }

    private fun changeDirectory(target: String) {
        if (target.isBlank() || target == "~") {
            appendTermOut(FileManager.projectDir + "\n")
            return
        }
        val dir = File(resolvePath(target))
        if (!dir.exists() || !dir.isDirectory) {
            appendTermErr("cd: ${dir.absolutePath}: No such file or directory\n")
            return
        }
        if (!dir.canRead()) {
            appendTermErr("cd: ${dir.absolutePath}: Permission denied\n")
            return
        }
        pickDir = dir
        appendTermOut(dir.absolutePath + "\n")
    }

    private fun listDirectory(path: String) {
        val dir = File(path)
        if (!dir.isDirectory) {
            appendTermErr("ls: cannot access '${dir.absolutePath}'\n")
            return
        }
        val children = FileManager.listChildren(dir, showAll = true)
        if (children.isEmpty()) {
            appendTermInfo("(empty)\n")
            return
        }
        val sb = StringBuilder()
        for (c in children) {
            if (c.isDirectory) {
                sb.append("<DIR>          ").append(c.name).append("/\n")
            } else {
                sb.append(String.format(Locale.US, "%9d  ", c.length()))
                    .append(c.name)
                    .append("\n")
            }
        }
        appendTermOut(sb.toString())
    }

    private fun catFile(path: String) {
        val file = File(path)
        if (!file.exists() || file.isDirectory) {
            appendTermErr("cat: ${file.name}: No such file or directory\n")
            return
        }
        val text = FileManager.readText(file)
        appendTermOut(
            if (text.length > 20000) text.take(20000) + "\n... (truncated)\n" else text + "\n"
        )
    }

    /** Anything unknown goes to the real Android shell (toybox / mksh). */
    private fun shellCommand(command: String) {
        Thread {
            try {
                val process = ProcessBuilder("/system/bin/sh", "-c", command)
                    .directory(FileManager.projectRoot())
                    .redirectErrorStream(false)
                    .start()
                val stdout = process.inputStream.bufferedReader().use { it.readText() }
                val stderr = process.errorStream.bufferedReader().use { it.readText() }
                val code = process.waitFor()
                if (stdout.isNotEmpty()) appendTermOut(stdout)
                if (stderr.isNotEmpty()) appendTermErr(stderr)
                if (code != 0 && stdout.isEmpty() && stderr.isEmpty()) {
                    appendTermErr("exit code $code\n")
                }
            } catch (t: Throwable) {
                appendTermErr("shell: ${t.message ?: t}\n")
            }
        }.start()
    }

    private fun resolvePath(arg: String?): String {
        val value = arg ?: "."
        if (value.startsWith("/")) return value
        if (value == "~") return FileManager.projectDir
        var current = pickDir ?: FileManager.projectRoot()
        for (part in value.split("/")) {
            when (part) {
                "", "." -> Unit
                ".." -> current = current.parentFile ?: current
                else -> current = File(current, part)
            }
        }
        return current.absolutePath
    }

    private fun tokenize(input: String): List<String> {
        val out = ArrayList<String>()
        val current = StringBuilder()
        var quote: Char? = null
        for (c in input) {
            when {
                quote != null -> if (c == quote) quote = null else current.append(c)
                c == '"' || c == '\'' -> quote = c
                c.isWhitespace() -> {
                    if (current.isNotEmpty()) {
                        out.add(current.toString())
                        current.setLength(0)
                    }
                }
                else -> current.append(c)
            }
        }
        if (current.isNotEmpty()) out.add(current.toString())
        return out
    }

    private fun appendTermOut(text: String) =
        terminalAdapter.append(OutputEvent(OutputEvent.Kind.TERM_OUT, text))

    private fun appendTermErr(text: String) =
        terminalAdapter.append(OutputEvent(OutputEvent.Kind.TERM_ERR, text))

    private fun appendTermInfo(text: String) =
        terminalAdapter.append(OutputEvent(OutputEvent.Kind.TERM_INFO, text))

    private fun scrollBottom(list: RecyclerView, adapter: RecyclerView.Adapter<*>) {
        if (adapter.itemCount > 0) list.scrollToPosition(adapter.itemCount - 1)
    }

    // ============================================================ events ===
    private fun onOutputEvent(event: OutputEvent) {
        when (event.kind) {
            OutputEvent.Kind.STDOUT,
            OutputEvent.Kind.STDERR,
            OutputEvent.Kind.ERROR,
            OutputEvent.Kind.INFO,
            OutputEvent.Kind.IMAGE -> {
                outputAdapter.append(event)
                outputEmpty.visibility = View.GONE
                scrollBottom(outputList, outputAdapter)
                if (event.kind == OutputEvent.Kind.IMAGE && pane != Pane.OUTPUT) {
                    appendTermInfo("[PyStudio] new figure -> Output tab\n")
                }
            }

            OutputEvent.Kind.RUNNING -> outputStatus.text =
                getString(R.string.output_running) + "  " + formatSeconds(event.seconds ?: 0.0)

            OutputEvent.Kind.DONE -> outputStatus.text =
                getString(R.string.output_finished) + "  " +
                event.text.ifEmpty { "exit" } + "  " +
                formatSeconds(event.seconds ?: 0.0)

            OutputEvent.Kind.CLEAR -> outputAdapter.clear()

            OutputEvent.Kind.TERM_OUT,
            OutputEvent.Kind.TERM_ERR,
            OutputEvent.Kind.TERM_INFO -> {
                terminalAdapter.append(event)
                scrollBottom(terminalList, terminalAdapter)
            }

            OutputEvent.Kind.INPUT_REQUEST -> {
                inputRow.visibility = View.VISIBLE
                inputPrompt.text = event.text.ifEmpty { "input: " }
                inputField.requestFocus()
                showPane(Pane.OUTPUT)
            }

            OutputEvent.Kind.INPUT_CLOSED -> inputRow.visibility = View.GONE
        }
    }

    // ==================================================== insert file path =
    private fun insertFilePath() {
        val insideCall = isInsideCallParenthesis(codeEditor.selectionEnd)
        showPickFileDialog { picked ->
            val quoted = "\"${picked.absolutePath}\""
            val text = codeEditor.text ?: return@showPickFileDialog
            val pos = codeEditor.selectionEnd.coerceIn(0, text.length)
            val insert = if (insideCall && needsCommaBefore(pos)) ", " + quoted else quoted
            text.insert(pos, insert)
            codeEditor.setSelection(pos + insert.length)
            if (!insideCall) {
                Toast.makeText(this, R.string.msg_no_function_call, Toast.LENGTH_SHORT).show()
            }
            scheduleHighlight()
        }
    }

    /** true when the caret sits inside the argument list of a function call. */
    private fun isInsideCallParenthesis(cursor: Int): Boolean {
        val text = codeEditor.text?.toString() ?: return false
        if (cursor <= 0 || cursor > text.length) return false
        var depth = 0
        var open = -1
        var i = cursor - 1
        while (i >= 0) {
            val c = text[i]
            if (c == ')') depth++
            if (c == '(') {
                if (depth == 0) {
                    open = i
                    break
                }
                depth--
            }
            i--
        }
        if (open < 0) return false
        for (j in open until cursor) {
            if (text[j] == ')') return false
        }
        var k = open - 1
        while (k >= 0 && text[k].isWhitespace()) k--
        var end = k + 1
        while (k >= 0 && (text[k].isLetterOrDigit() || text[k] == '_')) k--
        if (k >= 0 && text[k] == '.') {
            k--
            while (k >= 0 && (text[k].isLetterOrDigit() || text[k] == '_')) k--
        }
        if (end > k + 1) {
            val word = text.substring(k + 1, end)
            return word.isNotEmpty() && word[0].isLetter()
        }
        return false
    }

    private fun needsCommaBefore(pos: Int): Boolean {
        val text = codeEditor.text?.toString() ?: return false
        var i = pos - 1
        while (i >= 0 && text[i].isWhitespace()) i--
        if (i < 0) return false
        return text[i] != '(' && text[i] != ',' && text[i] != '['
    }

    // ============================================================== tabs ===
    private fun setupBottomNav() {
        bottomNav.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.tabEditor -> showPane(Pane.EDITOR)
                R.id.tabOutput -> showPane(Pane.OUTPUT)
                R.id.tabTerminal -> showPane(Pane.TERMINAL)
            }
            true
        }
        bottomNav.selectedItemId = R.id.tabEditor
    }

    private fun showPane(target: Pane) {
        pane = target
        paneEditor.visibility = if (target == Pane.EDITOR) View.VISIBLE else View.GONE
        paneOutput.visibility = if (target == Pane.OUTPUT) View.VISIBLE else View.GONE
        paneTerminal.visibility = if (target == Pane.TERMINAL) View.VISIBLE else View.GONE
        when (target) {
            Pane.EDITOR -> {
                codeEditor.requestFocus()
                updateCursorLabels()
            }
            Pane.OUTPUT -> scrollBottom(outputList, outputAdapter)
            Pane.TERMINAL -> {
                scrollBottom(terminalList, terminalAdapter)
                terminalInput.requestFocus()
            }
        }
    }

    // ========================================================== toolbar ====
    private fun setupToolbar() {
        toolbar.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                R.id.actionRun -> {
                    runCode(); true
                }
                R.id.actionSave -> {
                    saveCurrent(true); true
                }
                R.id.actionOpen -> {
                    showFilesDialog(FilesMode.OPEN); true
                }
                R.id.actionFiles -> {
                    showFilesDialog(FilesMode.OPEN); true
                }
                R.id.actionAbout -> {
                    showAbout(); true
                }
                else -> false
            }
        }
    }

    private fun showAbout() {
        AlertDialog.Builder(this)
            .setTitle(R.string.about_title)
            .setMessage(
                getString(R.string.about_text) + "\n\n" +
                    "Python " + PythonEngine.versionSafe() + "  |  Chaquopy\n" +
                    "project folder: " + FileManager.projectDir + "\n\n" +
                    "Stop raises KeyboardInterrupt after the current statement; a long " +
                    "C/C++ call (numpy, cv2) can only be interrupted once it returns."
            )
            .setPositiveButton(R.string.ok, null)
            .show()
    }

    // =========================================================== dialogs ===
    private fun showFilesDialog(mode: FilesMode) {
        filesMode = mode
        val view = LayoutInflater.from(this).inflate(R.layout.dialog_files, null)
        val list = view.findViewById<RecyclerView>(R.id.fileList)
        val subtitle = view.findViewById<TextView>(R.id.dialogSubtitle)
        filesAdapter = FileAdapter(filesItems, { picked -> onFilePicked(picked) }) { picked ->
            AlertDialog.Builder(this)
                .setTitle(picked.name)
                .setMessage(
                    getString(R.string.delete) + " / " + picked.absolutePath
                )
                .setPositiveButton(R.string.delete) { _, _ ->
                    if (picked.delete()) {
                        filesAdapter.submit(
                            FileManager.listChildren(filesDirCurrent ?: FileManager.projectRoot(), false)
                        )
                    }
                }
                .setNegativeButton(R.string.cancel, null)
                .show()
        }
        list.layoutManager = filesLayoutManager
        list.adapter = filesAdapter

        filesDirCurrent = currentFile?.parentFile ?: FileManager.projectRoot()
        subtitle.text = filesDirCurrent!!.absolutePath
        filesAdapter.submit(FileManager.listChildren(filesDirCurrent!!, showAll = false))

        val dialog = AlertDialog.Builder(this).setView(view).create()
        filesDialog = dialog

        view.findViewById<TextView>(R.id.btnNewFile).setOnClickListener {
            dialog.dismiss()
            newFilePrompt()
        }
        view.findViewById<TextView>(R.id.btnCloseDialog).setOnClickListener { dialog.dismiss() }

        dialog.show()
    }

    private fun onFilePicked(picked: File) {
        if (picked.isDirectory) {
            filesDirCurrent = picked
            filesAdapter.submit(FileManager.listChildren(picked, showAll = false))
            return
        }
        when (filesMode) {
            FilesMode.OPEN -> {
                filesDialog?.dismiss()
                loadFile(picked)
            }
            FilesMode.SAVE_AS -> {
                filesDialog?.dismiss()
                currentFile = picked
                saveCurrent(true)
            }
        }
    }

    private fun showPickFileDialog(onPicked: (File) -> Unit) {
        val view = LayoutInflater.from(this).inflate(R.layout.dialog_pick_file, null)
        val list = view.findViewById<RecyclerView>(R.id.pickList)
        val pathLabel = view.findViewById<TextView>(R.id.pickPathLabel)

        if (!FileManager.hasFullAccess()) {
            Toast.makeText(this, R.string.msg_storage_needed, Toast.LENGTH_LONG).show()
        }

        pickAdapter = FileAdapter(pickItems) { picked ->
            if (picked.isDirectory) {
                pickDir = picked
                pathLabel.text = picked.absolutePath
                pickAdapter.submit(FileManager.listChildren(picked, showAll = true))
            } else {
                pickDialog?.dismiss()
                onPicked(picked)
            }
        }
        list.layoutManager = pickLayoutManager
        list.adapter = pickAdapter

        val root = pickDir ?: FileManager.projectRoot()
        pickDir = root
        pathLabel.text = root.absolutePath
        pickAdapter.submit(FileManager.listChildren(root, showAll = true))

        val dialog = AlertDialog.Builder(this).setView(view).create()
        pickDialog = dialog
        view.findViewById<TextView>(R.id.btnPickUp).setOnClickListener {
            val parent = (pickDir ?: root).parentFile
            if (parent != null && parent.canRead()) {
                pickDir = parent
                pathLabel.text = parent.absolutePath
                pickAdapter.submit(FileManager.listChildren(parent, showAll = true))
            }
        }
        view.findViewById<TextView>(R.id.btnPickCancel).setOnClickListener { dialog.dismiss() }
        dialog.show()
    }

    private fun promptDialog(title: String, initial: String, onOk: (String) -> Unit) {
        val view = LayoutInflater.from(this).inflate(R.layout.dialog_prompt, null)
        val field = view.findViewById<EditText>(R.id.promptField)
        field.setText(initial)
        field.setSelection(field.text?.length ?: 0)
        val dialog = AlertDialog.Builder(this).setView(view).create()
        view.findViewById<TextView>(R.id.btnPromptOk).setOnClickListener {
            dialog.dismiss()
            onOk(field.text?.toString()?.trim() ?: "")
        }
        view.findViewById<TextView>(R.id.btnPromptCancel).setOnClickListener { dialog.dismiss() }
        dialog.show()
    }

    private fun maybeAskForStorage() {
        if (FileManager.hasFullAccess()) return
        AlertDialog.Builder(this)
            .setTitle(R.string.msg_storage_needed)
            .setMessage(
                "PyStudio keeps your Python files in /storage/emulated/0/PyStudio. " +
                    "Allow \"All files access\" so that cv2.imread() and open() can read " +
                    "any file on the phone."
            )
            .setPositiveButton(R.string.grant_access) { _, _ ->
                FileManager.requestFullAccess(this)
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    // ============================================================= misc ====
    override fun onPause() {
        super.onPause()
        saveCurrent(false)
        getPreferences(MODE_PRIVATE).edit()
            .putString(KEY_LAST_FILE, currentFile?.absolutePath)
            .apply()
    }

    override fun onDestroy() {
        super.onDestroy()
        OutputBus.unsubscribe(::onOutputEvent)
        PythonEngine.releaseInput()
        main.removeCallbacksAndMessages(null)
    }

    companion object {
        private const val KEY_LAST_FILE = "lastFile"

        private val HELP_TEXT = """
            PyStudio terminal

              python [script.py] [args]    run a script / start an interactive console
              python -c "print(1+1)"       evaluate a snippet
              pip install <package>        install a pure-Python package from PyPI
              pip list                     show bundled + runtime packages
              pip uninstall <package>      remove a runtime package
              ls [path]                    list files
              cd <path>                    change folder
              pwd                          print working folder
              cat <file>                   print a text file
              clear                        clear the terminal
              help                         this text

              anything else is passed to the real Android shell (toybox):
              mkdir / rm / cp / mv / touch / du / df / grep / tar / unzip ...

              project folder: /storage/emulated/0/PyStudio
        """.trimIndent()
    }
}
