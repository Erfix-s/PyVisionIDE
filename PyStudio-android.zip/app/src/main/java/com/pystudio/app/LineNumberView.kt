package com.pystudio.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.util.AttributeSet
import android.view.View
import android.widget.EditText
import androidx.core.content.ContextCompat
import kotlin.math.max

/**
 * Slim gutter that shows line numbers and stays in sync with the code editor
 * (including its internal scrolling).
 */
class LineNumberView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Typeface.MONOSPACE
        textSize = resources.displayMetrics.scaledDensity * 12f
        textAlign = Paint.Align.RIGHT
        color = ContextCompat.getColor(context, R.color.editorGutterText)
    }

    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = ContextCompat.getColor(context, R.color.primary)
    }

    private val normalColor = ContextCompat.getColor(context, R.color.editorGutterText)
    private val activeColor = ContextCompat.getColor(context, R.color.primary)

    private var editor: EditText? = null
    private var lineCount = 1
    private var lineHeight = resources.displayMetrics.scaledDensity * 18f
    private var scrollOffset = 0f
    private var padTop = 0f
    private var cursorLine = 0
    private var rightPad = resources.displayMetrics.density * 8f
    private var leftPad = resources.displayMetrics.density * 4f

    fun attach(target: EditText) {
        editor = target
        padTop = target.paddingTop.toFloat()
        lineHeight = max(1f, target.lineHeight.toFloat())
        target.setOnScrollChangeListener { _, _, scrollY, _, _ ->
            scrollOffset = scrollY.toFloat()
            invalidate()
        }
        refresh()
    }

    fun refresh() {
        val ed = editor ?: return
        val layout = ed.layout ?: return
        lineCount = max(1, layout.lineCount)
        lineHeight = max(1f, ed.lineHeight.toFloat())
        padTop = ed.paddingTop.toFloat()
        scrollOffset = ed.scrollY.toFloat()
        val start = ed.selectionStart
        cursorLine = if (start >= 0 && layout.lineCount > 0) {
            layout.getLineForOffset(start)
        } else {
            -1
        }
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val fm = textPaint.fontMetrics
        val ascent = fm.ascent
        val padLeft = leftPad

        // subtle highlight of the current line
        if (cursorLine >= 0) {
            val top = padTop + cursorLine * lineHeight - scrollOffset
            if (top > -lineHeight && top < height) {
                linePaint.alpha = 40
                canvas.drawRect(0f, top, width.toFloat(), top + lineHeight, linePaint)
                linePaint.alpha = 255
            }
        }

        val total = max(lineCount, 1)
        for (i in 0 until total) {
            val top = padTop + i * lineHeight - scrollOffset
            if (top + lineHeight < 0 || top > height) continue
            textPaint.color = if (i == cursorLine) activeColor else normalColor
            canvas.drawText(
                (i + 1).toString(),
                width - rightPad,
                top - ascent + (lineHeight - (fm.descent - ascent)) * 0.5f,
                textPaint
            )
        }
        padLeft.let { /* keeps kotlin happy about unused val */ }
    }
}
