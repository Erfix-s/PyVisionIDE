package com.pystudio.app

import android.graphics.BitmapFactory
import android.graphics.Color
import android.util.Base64
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

/**
 * Renders the Output tab: text lines, error blocks and rendered figures.
 */
class OutputAdapter(
    private val items: MutableList<OutputEvent>,
    private val onSaveImage: (ByteArray, String) -> Unit
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    private class TextVH(val tv: TextView) : RecyclerView.ViewHolder(tv as View)

    private class ImageVH(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val iv: ImageView = itemView.findViewById(R.id.outputImage)
        val title: TextView = itemView.findViewById(R.id.imageTitle)
        val action: TextView = itemView.findViewById(R.id.imageAction)
    }

    companion object {
        private const val TYPE_TEXT = 0
        private const val TYPE_ERROR = 1
        private const val TYPE_IMAGE = 2
        private const val MAX_ITEMS = 400
        private const val MERGE_LENGTH = 6000
        private val COLOR_STDOUT = Color.parseColor("#E6EDF3")
        private val COLOR_ERROR = Color.parseColor("#FF6B6B")
        private val COLOR_INFO = Color.parseColor("#3DDC97")
    }

    override fun getItemViewType(position: Int): Int = when (items[position].kind) {
        OutputEvent.Kind.ERROR -> TYPE_ERROR
        OutputEvent.Kind.IMAGE -> TYPE_IMAGE
        else -> TYPE_TEXT
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val inf = LayoutInflater.from(parent.context)
        return when (viewType) {
            TYPE_IMAGE -> ImageVH(inf.inflate(R.layout.item_output_image, parent, false))
            TYPE_ERROR -> TextVH(inf.inflate(R.layout.item_output_text, parent, false) as TextView)
            else -> TextVH(inf.inflate(R.layout.item_output_text, parent, false) as TextView)
        }
    }

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val event = items[position]
        when (holder) {
            is ImageVH -> {
                holder.title.text = event.title.ifEmpty { "figure" }
                val bytes = decode(event.imageBase64)
                holder.iv.setImageBitmap(if (bytes == null) null else decodeSampled(bytes))
                holder.action.setOnClickListener {
                    decode(event.imageBase64)?.let { b -> onSaveImage(b, event.title) }
                }
            }

            is TextVH -> {
                holder.tv.text = event.text
                holder.tv.setTextColor(
                    when (event.kind) {
                        OutputEvent.Kind.ERROR, OutputEvent.Kind.STDERR -> COLOR_ERROR
                        OutputEvent.Kind.INFO -> COLOR_INFO
                        else -> COLOR_STDOUT
                    }
                )
            }

            else -> {}
        }
    }

    private fun decode(base: String?): ByteArray? = try {
        Base64.decode(base ?: return null, Base64.DEFAULT)
    } catch (_: Throwable) {
        null
    }

    private fun decodeSampled(bytes: ByteArray): android.graphics.Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        var sample = 1
        var maxSide = maxOf(bounds.outWidth, bounds.outHeight)
        while (maxSide / sample > 1600) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts)
    }

    /** Appends an event, merging consecutive text rows to keep the list small. */
    fun append(event: OutputEvent) {
        val kind = event.kind
        if (kind == OutputEvent.Kind.IMAGE) {
            items.add(event)
        } else {
            val last = items.lastOrNull()
            if (last != null && last.kind == kind) {
                val merged = (last.text + event.text).takeLast(MERGE_LENGTH)
                items[items.size - 1] = last.copy(text = merged)
                notifyItemChanged(items.size - 1)
                return
            }
            items.add(event)
        }
        if (items.size > MAX_ITEMS) {
            val drop = items.size - MAX_ITEMS
            repeat(drop) { items.removeAt(0) }
            notifyDataSetChanged()
        } else {
            notifyItemInserted(items.size - 1)
        }
    }

    fun clear() {
        items.clear()
        notifyDataSetChanged()
    }
}
