package com.pystudio.app

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.Settings
import java.io.File

/**
 * Everything about files on the phone.
 *
 * The project folder is `/storage/emulated/0/PyStudio` when the user grants
 * "All files access"; otherwise it falls back to the app-specific external
 * directory (no permission needed) so the app still works.
 */
object FileManager {

    const val PROJECT_FOLDER = "PyStudio"

    @Volatile
    var projectDir: String = ""
        private set

    private lateinit var appContext: Context

    fun init(context: Context) {
        appContext = context.applicationContext
        val publicRoot = File(Environment.getExternalStorageDirectory(), PROJECT_FOLDER)
        projectDir = if (publicRoot.isDirectory || publicRoot.parentFile?.canWrite() == true) {
            publicRoot.absolutePath
        } else {
            File(context.getExternalFilesDir(null), PROJECT_FOLDER).absolutePath
        }
        ensureDirs()
    }

    fun projectRoot(): File = File(projectDir)

    fun outputDir(): File = File(projectDir, "output")

    fun ensureDirs() {
        try {
            projectRoot().mkdirs()
            outputDir().mkdirs()
            File(projectDir, ".samples_done").let { if (!it.exists()) writeDefaultSamples() }
        } catch (_: Throwable) {
        }
    }

    // ------------------------------------------------------------- samples ---
    fun writeDefaultSamples() {
        val files = linkedMapOf(
            "main.py" to SAMPLE_MAIN,
            "image_processing.py" to SAMPLE_IMAGE,
            "plot_demo.py" to SAMPLE_PLOT
        )
        for ((name, body) in files) {
            val f = File(projectDir, name)
            if (!f.exists()) {
                try {
                    f.writeText(body)
                } catch (_: Throwable) {
                }
            }
        }
        File(projectDir, ".samples_done").writeText("1")
    }

    // --------------------------------------------------------- permissions ---
    fun hasFullAccess(): Boolean = try {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            Environment.isExternalStorageManager()
        } else {
            Environment.getExternalStorageDirectory().canWrite()
        }
    } catch (_: Throwable) {
        false
    }

    fun requestFullAccess(activity: Activity) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                val uri = Uri.parse("package:${activity.packageName}")
                val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, uri)
                activity.startActivity(intent)
            } else {
                activity.requestPermissions(
                    arrayOf(
                        android.Manifest.permission.READ_EXTERNAL_STORAGE,
                        android.Manifest.permission.WRITE_EXTERNAL_STORAGE
                    ),
                    41
                )
            }
        } catch (_: Throwable) {
            try {
                activity.startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
            } catch (_: Throwable) {
            }
        }
    }

    // ------------------------------------------------------------ file ops ---
    fun listChildren(dir: File, showAll: Boolean): List<File> {
        val list = dir.listFiles() ?: return emptyList()
        val filtered = list.filter {
            !it.name.startsWith(".") && (showAll || it.isDirectory || it.extension in TEXT_EXTENSIONS)
        }
        return filtered.sortedWith(
            compareByDescending<File> { it.isDirectory }.thenBy { it.name.lowercase() }
        )
    }

    val TEXT_EXTENSIONS = setOf("py", "txt", "json", "csv", "md", "yaml", "yml", "ini", "log")

    fun readText(file: File): String = try {
        file.readText(Charsets.UTF_8)
    } catch (_: Throwable) {
        ""
    }

    fun writeText(file: File, text: String): Boolean = try {
        file.parentFile?.mkdirs()
        file.writeText(text, Charsets.UTF_8)
        true
    } catch (_: Throwable) {
        false
    }

    /** Returns a unique file inside the project `output/` folder. */
    fun newOutputFile(baseName: String, extension: String): File {
        val dir = outputDir().apply { mkdirs() }
        val safe = baseName.replace(Regex("[^A-Za-z0-9._-]"), "_")
        var candidate = File(dir, "$safe.$extension")
        var i = 1
        while (candidate.exists()) {
            candidate = File(dir, "${safe}_$i.$extension")
            i++
        }
        return candidate
    }

    fun writeBytes(file: File, bytes: ByteArray): Boolean = try {
        file.parentFile?.mkdirs()
        file.writeBytes(bytes)
        true
    } catch (_: Throwable) {
        false
    }

    /** Human friendly path (used for `cv2.imread(...)` suggestions). */
    fun prettyPath(file: File): String = file.absolutePath
}

private const val SAMPLE_MAIN = """# PyStudio - welcome!
# Press the green "Run" button to execute this file.

import sys
import numpy as np

print("Python:", sys.version.split()[0])
print("NumPy :", np.__version__)

a = np.arange(1, 11)
print("a      =", a)
print("a * 2  =", a * 2)
print("mean   =", round(float(a.mean()), 3))

name = input("What is your name? ")
print(f"Hello {name}! PyStudio is running real CPython on your phone.")
"""

private const val SAMPLE_IMAGE = """# Image processing - OpenCV is bundled in the APK, just import it.
import cv2
import numpy as np
import os

# Create a gradient image (no camera needed)
img = np.zeros((240, 320, 3), dtype=np.uint8)
img[:, :, 2] = np.tile(np.linspace(40, 220, 320).astype(np.uint8), (240, 1))
img[:, :, 1] = np.tile(np.linspace(20, 180, 240).reshape(240, 1), (1, 320)).astype(np.uint8)

# Pick a real file with the "Insert file path" button, then use:
# img = cv2.imread("/storage/emulated/0/DCIM/Camera/IMG.jpg")

blur = cv2.GaussianBlur(img, (11, 11), 0)
edges = cv2.Canny(blur, 60, 160)

cv2.imshow("original", img)
cv2.imshow("blur", blur)
cv2.imshow("edges", edges)

out = os.path.join(os.path.dirname(os.path.abspath(__file__)), "output")
os.makedirs(out, exist_ok=True)
cv2.imwrite(os.path.join(out, "blur.png"), blur)
print("saved to", out)
"""

private const val SAMPLE_PLOT = """# Matplotlib figures are rendered as images in the Output tab.
import numpy as np
import matplotlib.pyplot as plt

x = np.linspace(-6, 6, 300)
plt.figure(figsize=(6, 4))
plt.plot(x, np.sin(x), label="sin(x)")
plt.plot(x, np.cos(x) * 0.6, label="0.6 cos(x)")
plt.title("PyStudio on Android")
plt.legend()
plt.grid(alpha=0.3)
plt.show()

plt.figure(figsize=(4, 4))
plt.hist(np.random.default_rng(0).normal(size=2000), bins=40, color="#7C9EFF")
plt.title("histogram")
plt.show()
print("done")
"""
