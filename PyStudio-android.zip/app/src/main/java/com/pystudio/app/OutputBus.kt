package com.pystudio.app

import android.os.Handler
import android.os.Looper
import java.util.concurrent.CopyOnWriteArrayList

/** One line / image / state-change of the output or terminal view. */
data class OutputEvent(
    val kind: Kind,
    val text: String = "",
    val imageBase64: String? = null,
    val title: String = "",
    val seconds: Double? = null
) {
    enum class Kind {
        STDOUT, STDERR, INFO, ERROR, IMAGE, CLEAR, DONE, RUNNING,
        TERM_OUT, TERM_ERR, TERM_INFO, INPUT_REQUEST, INPUT_CLOSED
    }
}

/**
 * Tiny event bus between the Python thread and the UI thread.
 */
object OutputBus {

    /** Where the Python print output currently goes. */
    enum class Sink { OUTPUT_TAB, TERMINAL }

    @Volatile
    var sink: Sink = Sink.OUTPUT_TAB

    private val main = Handler(Looper.getMainLooper())
    private val listeners = CopyOnWriteArrayList<(OutputEvent) -> Unit>()

    fun subscribe(listener: (OutputEvent) -> Unit) {
        listeners.add(listener)
    }

    fun unsubscribe(listener: (OutputEvent) -> Unit) {
        listeners.remove(listener)
    }

    fun post(event: OutputEvent) {
        if (Looper.myLooper() == Looper.getMainLooper()) {
            listeners.forEach { it(event) }
        } else {
            main.post { listeners.forEach { it(event) } }
        }
    }
}
