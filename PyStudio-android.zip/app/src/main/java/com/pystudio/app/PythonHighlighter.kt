package com.pystudio.app

import android.content.Context
import android.graphics.Typeface
import android.text.Editable
import android.text.SpannableStringBuilder
import android.text.style.ForegroundColorSpan
import android.text.style.StyleSpan
import androidx.core.content.ContextCompat

/**
 * Small, fast and dependency free Python tokenizer used to colour the editor.
 * The scan runs on a worker thread, spans are applied on the UI thread.
 */
class PythonHighlighter(context: Context) {

    data class Token(val start: Int, val end: Int, val color: Int, val italic: Boolean = false)

    private val cKeyword = ContextCompat.getColor(context, R.color.editorKeyword)
    private val cBuiltin = ContextCompat.getColor(context, R.color.editorBuiltin)
    private val cString = ContextCompat.getColor(context, R.color.editorString)
    private val cNumber = ContextCompat.getColor(context, R.color.editorNumber)
    private val cComment = ContextCompat.getColor(context, R.color.editorComment)
    private val cFunction = ContextCompat.getColor(context, R.color.editorFunction)
    private val cDecorator = ContextCompat.getColor(context, R.color.editorDecorator)
    private val cOperator = ContextCompat.getColor(context, R.color.editorOperator)
    private val cDefault = ContextCompat.getColor(context, R.color.editorText)

    fun scan(text: CharSequence): List<Token> {
        val out = ArrayList<Token>(128)
        val n = text.length
        var i = 0
        var triple: Char? = null

        while (i < n) {
            val c = text[i]

            if (triple != null) {
                if (c == triple && i + 2 < n && text[i + 1] == triple && text[i + 2] == triple) {
                    i += 3
                    triple = null
                    out.add(Token(i - 3, i, cString))
                } else {
                    i++
                }
                continue
            }

            when {
                c == '#' -> {
                    var j = i
                    while (j < n && text[j] != '\n') j++
                    out.add(Token(i, j, cComment))
                    i = j
                }

                c == '"' || c == '\'' -> {
                    if (i + 2 < n && text[i + 1] == c && text[i + 2] == c) {
                        // triple quoted string - may span several lines
                        val start = i
                        i += 3
                        triple = c
                        if (i >= n) {
                            out.add(Token(start, i, cString))
                            triple = null
                        } else {
                            out.add(Token(start, i, cString))
                        }
                        continue
                    }
                    val start = i
                    i++
                    var closed = false
                    while (i < n) {
                        val q = text[i]
                        if (q == '\\' && i + 1 < n) {
                            i += 2
                            continue
                        }
                        if (q == c) {
                            i++
                            closed = true
                            break
                        }
                        if (q == '\n') break
                        i++
                    }
                    if (!closed) i = n.coerceAtMost(i)
                    out.add(Token(start, i, cString))
                }

                c.isLetter() || c == '_' -> {
                    val start = i
                    while (i < n && (text[i].isLetterOrDigit() || text[i] == '_')) i++
                    val word = text.subSequence(start, i).toString()
                    // string prefixes: r"...", f'...', b"..."
                    if (i < n && (text[i] == '"' || text[i] == '\'') &&
                        word.length <= 2 && word.all { it in "rbfuRBFU" }
                    ) {
                        val s0 = start
                        val quote = text[i]
                        i++
                        while (i < n) {
                            val q = text[i]
                            if (q == '\\' && i + 1 < n) {
                                i += 2
                                continue
                            }
                            if (q == quote || q == '\n') {
                                if (q == quote) i++
                                break
                            }
                            i++
                        }
                        out.add(Token(s0, i, cString))
                        continue
                    }
                    when {
                        word in KEYWORDS -> out.add(Token(start, i, cKeyword, italic = true))
                        word in CONSTANTS -> out.add(Token(start, i, cNumber))
                        word in BUILTINS -> out.add(Token(start, i, cBuiltin))
                        else -> {
                            // function call name?
                            var j = i
                            while (j < n && text[j] == ' ' || j < n && text[j] == '\t') j++
                            if (j < n && text[j] == '(') {
                                out.add(Token(start, i, cFunction))
                            } else {
                                out.add(Token(start, i, cDefault))
                            }
                        }
                    }
                }

                c.isDigit() -> {
                    val start = i
                    if (c == '0' && i + 1 < n && (text[i + 1] == 'x' || text[i + 1] == 'X')) {
                        i += 2
                        while (i < n && (text[i].isDigit() || text[i] in "abcdefABCDEF_")) i++
                    } else {
                        while (i < n && (text[i].isDigit() || text[i] == '_' ||
                                text[i] == '.' || text[i] == 'e' || text[i] == 'E' ||
                                ((text[i] == '+' || text[i] == '-') && i > start &&
                                    (text[i - 1] == 'e' || text[i - 1] == 'E')))
                        ) i++
                    }
                    out.add(Token(start, i, cNumber))
                }

                c == '@' && (i == 0 || text[i - 1] == '\n' || text[i - 1] == ' ') -> {
                    val start = i
                    i++
                    while (i < n && (text[i].isLetterOrDigit() || text[i] == '_' || text[i] == '.')) i++
                    out.add(Token(start, i, cDecorator))
                }

                c in "!+-*/%=<>&|^~:,;(){}[]()." -> {
                    val start = i
                    i++
                    out.add(Token(start, i, cOperator))
                }

                else -> i++
            }
        }
        return out
    }

    /** Removes old colour spans and applies the freshly scanned ones. */
    fun apply(editable: Editable, tokens: List<Token>) {
        val existing = editable.getSpans(0, editable.length, ForegroundColorSpan::class.java)
        for (s in existing) editable.removeSpan(s)
        val styles = editable.getSpans(0, editable.length, StyleSpan::class.java)
        for (s in styles) editable.removeSpan(s)

        val builder = editable as? SpannableStringBuilder ?: return
        for (t in tokens) {
            if (t.start < 0 || t.end > editable.length || t.start >= t.end) continue
            builder.setSpan(
                ForegroundColorSpan(t.color),
                t.start,
                t.end,
                SpannableStringBuilder.SPAN_EXCLUSIVE_EXCLUSIVE
            )
            if (t.italic) {
                builder.setSpan(
                    StyleSpan(Typeface.ITALIC),
                    t.start,
                    t.end,
                    SpannableStringBuilder.SPAN_EXCLUSIVE_EXCLUSIVE
                )
            }
        }
    }

    companion object {
        private val KEYWORDS = setOf(
            "and", "as", "assert", "async", "await", "break", "class", "continue", "def",
            "del", "elif", "else", "except", "finally", "for", "from", "global", "if",
            "import", "in", "is", "lambda", "nonlocal", "not", "or", "pass", "raise",
            "return", "try", "while", "with", "yield", "match", "case"
        )
        private val CONSTANTS = setOf(
            "True", "False", "None", "self", "cls", "__name__", "__main__", "__file__"
        )
        private val BUILTINS = setOf(
            "abs", "aiter", "all", "any", "bin", "bool", "bytearray", "bytes", "callable",
            "chr", "classmethod", "compile", "complex", "delattr", "dict", "dir", "divmod",
            "enumerate", "eval", "exec", "filter", "float", "format", "frozenset", "getattr",
            "globals", "hasattr", "hash", "help", "hex", "id", "input", "int", "isinstance",
            "issubclass", "iter", "len", "list", "locals", "map", "max", "min", "next",
            "object", "oct", "open", "ord", "pow", "print", "property", "range", "repr",
            "reversed", "round", "set", "setattr", "slice", "sorted", "staticmethod", "str",
            "sum", "super", "tuple", "type", "vars", "zip",
            "cv2", "np", "plt", "pd", "tf", "Image"
        )
    }
}
