package com.pystudio.app

import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit

/**
 * Called from Python (see `pystudio_runner.py`).
 *
 * Every method here must be public, take/return only simple Java types and never
 * touch the UI thread directly - it forwards to [OutputBus] instead.
 */
class OutputBridge {

    // ---------------------------------------------------------------- text ---
    fun writeStdout(text: String) {
        when (OutputBus.sink) {
            OutputBus.Sink.TERMINAL -> OutputBus.post(OutputEvent(OutputEvent.Kind.TERM_OUT, text))
            OutputBus.Sink.OUTPUT_TAB -> OutputBus.post(OutputEvent(OutputEvent.Kind.STDOUT, text))
        }
    }

    fun writeStderr(text: String) {
        when (OutputBus.sink) {
            OutputBus.Sink.TERMINAL -> OutputBus.post(OutputEvent(OutputEvent.Kind.TERM_ERR, text))
            OutputBus.Sink.OUTPUT_TAB -> OutputBus.post(OutputEvent(OutputEvent.Kind.STDERR, text))
        }
    }

    fun writeInfo(text: String) {
        OutputBus.post(OutputEvent(OutputEvent.Kind.TERM_INFO, text))
    }

    fun writeErrorBlock(text: String) {
        when (OutputBus.sink) {
            OutputBus.Sink.TERMINAL ->
                OutputBus.post(OutputEvent(OutputEvent.Kind.TERM_ERR, text))
            OutputBus.Sink.OUTPUT_TAB ->
                OutputBus.post(OutputEvent(OutputEvent.Kind.ERROR, text))
        }
    }

    // --------------------------------------------------------------- images ---
    fun emitImage(base64Png: String, title: String) {
        OutputBus.post(OutputEvent(OutputEvent.Kind.IMAGE, imageBase64 = base64Png, title = title))
    }

    fun clearOutput() {
        OutputBus.post(OutputEvent(OutputEvent.Kind.CLEAR))
    }

    // ---------------------------------------------------------------- state ---
    fun running(seconds: Double) {
        OutputBus.post(OutputEvent(OutputEvent.Kind.RUNNING, seconds = seconds))
    }

    fun finished(exitCode: Int, summary: String, seconds: Double) {
        OutputBus.post(
            OutputEvent(OutputEvent.Kind.DONE, text = summary, seconds = seconds)
        )
        OutputBus.post(OutputEvent(OutputEvent.Kind.INPUT_CLOSED))
    }

    // --------------------------------------------------------- stdin (input) --
    private val inputQueue = LinkedBlockingQueue<String>()

    /**
     * Blocks the Python thread until the user types something in the Output tab.
     */
    fun requestInput(): String {
        OutputBus.post(OutputEvent(OutputEvent.Kind.INPUT_REQUEST))
        return try {
            inputQueue.poll(10, TimeUnit.MINUTES) ?: ""
        } catch (_: InterruptedException) {
            ""
        } finally {
            OutputBus.post(OutputEvent(OutputEvent.Kind.INPUT_CLOSED))
        }
    }

    /** Called by the UI when the user pressed "send". */
    fun submitInput(value: String) {
        inputQueue.offer(value)
    }

    /** Called by the UI when the script is stopped / cleared. */
    fun releaseInput() {
        inputQueue.offer("")
    }
}
