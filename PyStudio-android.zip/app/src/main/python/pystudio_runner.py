"""
PyStudio runner - the Python side of the Android app.

This module is bundled into the APK by Chaquopy and is called from Kotlin
(`PythonEngine.kt`). It is responsible for:

  * redirecting sys.stdout / sys.stderr to the Android UI (Output tab / Terminal)
  * making the GUI entry points of matplotlib, OpenCV and Pillow work on a phone
    by rendering them into PNG images that are pushed to the Output tab
  * making builtins.input() work (the Output tab shows a prompt)
  * running scripts and single REPL lines with clean tracebacks
  * a small "pip" that installs pure-Python wheels from PyPI at runtime
    (packages with native code must be bundled at build time, see build.gradle)
"""

import base64
import builtins
import importlib
import importlib.abc
import io
import json
import os
import re
import sys
import time
import traceback
import urllib.error
import urllib.request
import zipfile

_BRIDGE = None
_FILES_DIR = ""
_CACHE_DIR = ""
_PROJECT_DIR = ""
_SITE_DIR = ""

_STOP = {"v": False}
_REPL_GLOBALS = {"__name__": "__pyconsole__", "__doc__": None}
_INSTALLED_MANIFEST = "pystudio_installed.json"


# --------------------------------------------------------------------------
# setup
# --------------------------------------------------------------------------
def python_version():
    return "%d.%d.%d" % sys.version_info[:3]


def setup(bridge, files_dir, cache_dir, project_dir, site_dir):
    global _BRIDGE, _FILES_DIR, _CACHE_DIR, _PROJECT_DIR, _SITE_DIR

    _BRIDGE = bridge
    _FILES_DIR = files_dir
    _CACHE_DIR = cache_dir
    _PROJECT_DIR = project_dir
    _SITE_DIR = site_dir

    # Writable folders for libraries that expect a unix-like environment.
    os.environ.setdefault("HOME", files_dir)
    os.environ["TMPDIR"] = os.path.join(cache_dir, "tmp")
    os.environ["MPLCONFIGDIR"] = os.path.join(cache_dir, "mplconfig")
    os.environ["MPLBACKEND"] = "Agg"
    os.environ["PYTHONUNBUFFERED"] = "1"
    os.environ["NO_COLOR"] = "1"
    for path in (os.environ["TMPDIR"], os.environ["MPLCONFIGDIR"]):
        try:
            os.makedirs(path, exist_ok=True)
        except Exception:
            pass

    # Where user code and runtime-installed packages live.
    for p in (site_dir, project_dir):
        if p and p not in sys.path:
            sys.path.insert(0, p)

    sys.stdout = _Stream(bridge.writeStdout)
    sys.stderr = _Stream(bridge.writeStderr)
    builtins.input = _py_input

    _install_gui_patches()


def request_stop():
    _STOP["v"] = True


# --------------------------------------------------------------------------
# output redirection
# --------------------------------------------------------------------------
class _BufferProxy(object):
    """Minimal `sys.stdout.buffer` for libraries that write bytes."""

    def __init__(self, stream):
        self._stream = stream

    def write(self, data):
        try:
            self._stream.write(data.decode("utf-8", "replace"))
        except Exception:
            pass
        return len(data)

    def flush(self):
        self._stream.flush()

    def writable(self):
        return True


class _Stream(object):
    def __init__(self, emit):
        self.emit = emit
        self.buf = []
        self.encoding = "utf-8"
        self.errors = "replace"
        self.name = "<pystudio>"
        self.buffer = _BufferProxy(self)

    def write(self, text):
        if not text:
            return
        self.buf.append(text)
        joined = "".join(self.buf)
        if len(joined) >= 400 or joined.endswith("\n"):
            self.flush()

    def flush(self):
        if self.buf:
            text = "".join(self.buf)
            self.buf = []
            if text:
                try:
                    self.emit(text)
                except Exception:
                    pass

    def isatty(self):
        return False

    def writable(self):
        return True

    def readable(self):
        return False

    def seekable(self):
        return False

    def close(self):
        self.flush()

    def fileno(self):
        raise io.UnsupportedOperation("fileno")


def _flush_streams():
    try:
        sys.stdout.flush()
        sys.stderr.flush()
    except Exception:
        pass


def _py_input(prompt=""):
    _flush_streams()
    if prompt:
        try:
            sys.stdout.write(str(prompt))
            sys.stdout.flush()
        except Exception:
            pass
    return _BRIDGE.requestInput()


# --------------------------------------------------------------------------
# GUI library patching (import hooks)
# --------------------------------------------------------------------------
class _PatchingLoader(importlib.abc.Loader):
    def __init__(self, inner):
        self.inner = inner

    def create_module(self, spec):
        try:
            return self.inner.create_module(spec)
        except AttributeError:
            return None

    def exec_module(self, module):
        self.inner.exec_module(module)
        try:
            _patch_module(module.__name__)
        except Exception:
            pass


class _PatchingFinder(importlib.abc.MetaPathFinder):
    TARGETS = {
        "matplotlib",
        "matplotlib.pyplot",
        "cv2",
        "PIL",
        "PIL.Image",
        "matplotlib.figure",
    }

    def find_spec(self, fullname, path=None, target=None):
        if fullname not in self.TARGETS:
            return None
        for finder in sys.meta_path:
            if finder is self:
                continue
            try:
                spec = finder.find_spec(fullname, path, target)
            except Exception:
                spec = None
            if spec is not None and spec.loader is not None:
                spec.loader = _PatchingLoader(spec.loader)
                return spec
        return None


def _install_gui_patches():
    if not any(isinstance(f, _PatchingFinder) for f in sys.meta_path):
        sys.meta_path.insert(0, _PatchingFinder())


def _patch_module(name):
    if name == "matplotlib":
        try:
            import matplotlib

            matplotlib.use("Agg", force=True)
        except Exception:
            pass
        return

    if name == "matplotlib.pyplot":
        import matplotlib.pyplot as plt

        plt.show = _plt_show
        plt.pause = _plt_pause
        return

    if name == "cv2":
        import cv2

        cv2.imshow = _cv2_imshow
        cv2.waitKey = lambda *a, **k: 0
        cv2.waitKeyEx = lambda *a, **k: 0
        cv2.destroyAllWindows = lambda *a, **k: None
        cv2.destroyWindow = lambda *a, **k: None
        cv2.namedWindow = lambda *a, **k: None
        cv2.resizeWindow = lambda *a, **k: None
        cv2.moveWindow = lambda *a, **k: None
        cv2.startWindowThread = lambda *a, **k: None
        cv2.setWindowProperty = lambda *a, **k: None
        cv2.createTrackbar = lambda *a, **k: None
        return

    if name == "PIL.Image":
        from PIL import Image

        Image.Image.show = _pil_show
        return


# --------------------------------------------------------------------------
# image helpers
# --------------------------------------------------------------------------
def _to_uint8(array):
    import numpy as np

    a = np.asarray(array)
    if a.dtype == np.uint8:
        return a
    if a.dtype.kind == "f":
        try:
            top = float(a.max())
        except Exception:
            top = 1.0
        if top <= 1.0:
            a = a * 255.0
        a = np.clip(a, 0, 255)
    elif a.dtype.kind in "ib":
        a = np.clip(a, 0, 255)
    return a.astype("uint8")


def _array_to_png(array):
    from PIL import Image

    a = _to_uint8(array)
    if a.ndim == 3 and a.shape[2] == 3:
        mode = "RGB"
    elif a.ndim == 3 and a.shape[2] == 4:
        mode = "RGBA"
    else:
        mode = "L"
    img = Image.fromarray(a, mode)
    return _pil_to_png(img)


def _pil_to_png(img):
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    return base64.b64encode(buf.getvalue()).decode("ascii")


def _fig_to_png(fig):
    try:
        buf = io.BytesIO()
        fig.savefig(buf, format="png", dpi=120, bbox_inches="tight", facecolor="#0E131A")
        return base64.b64encode(buf.getvalue()).decode("ascii")
    except Exception:
        fig.canvas.draw()
        buffer = fig.canvas.buffer_rgba()
        return _array_to_png(buffer)


def _emit_image(png_base64, title):
    if _BRIDGE is None:
        return
    try:
        _BRIDGE.emitImage(png_base64, title)
    except Exception as exc:
        _BRIDGE.writeStderr("[PyStudio] could not display image: %s\n" % exc)


# --------------------------------------------------------------------------
# patched GUI entry points
# --------------------------------------------------------------------------
def _plt_show(*args, **kwargs):
    try:
        import matplotlib.pyplot as plt

        nums = list(plt.get_fignums())
        if not nums:
            sys.stderr.write("[PyStudio] plt.show(): nothing to display\n")
            return
        for i, num in enumerate(nums, 1):
            fig = plt.figure(num)
            _emit_image(_fig_to_png(fig), "matplotlib figure %d" % i)
        plt.close("all")
        _flush_streams()
    except Exception as exc:
        sys.stderr.write("[PyStudio] matplotlib error: %s\n" % exc)


def _plt_pause(interval=0.0):
    _plt_show()
    try:
        time.sleep(float(interval))
    except Exception:
        pass


def _cv2_imshow(winname=None, mat=None):
    if mat is None:
        return
    try:
        import cv2

        img = mat
        if hasattr(img, "ndim"):
            if img.ndim == 3 and img.shape[2] == 3:
                img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
            elif img.ndim == 3 and img.shape[2] == 4:
                img = cv2.cvtColor(img, cv2.COLOR_BGRA2RGBA)
        _emit_image(_array_to_png(img), "cv2.imshow %s" % (winname or ""))
        _flush_streams()
    except Exception as exc:
        sys.stderr.write("[PyStudio] cv2.imshow failed: %s\n" % exc)


def _pil_show(self, title=None, command=None):
    try:
        img = self.convert("RGB") if self.mode not in ("RGB", "RGBA", "L") else self
        _emit_image(_pil_to_png(img), title or "PIL Image %sx%s" % self.size)
        _flush_streams()
    except Exception as exc:
        sys.stderr.write("[PyStudio] Image.show() failed: %s\n" % exc)


# --------------------------------------------------------------------------
# script execution
# --------------------------------------------------------------------------
def _clean_traceback(text):
    keep = []
    for line in text.splitlines():
        low = line.lower()
        if "pystudio_runner.py" in low:
            continue
        if "/com/chaquo" in low or "chaquopy" in low:
            continue
        keep.append(line)
    return "\n".join(keep).strip("\n")


def _report_error(exc):
    try:
        text = traceback.format_exception(type(exc), exc, exc.__traceback__)
        _BRIDGE.writeErrorBlock(_clean_traceback("".join(text)) + "\n")
    except Exception:
        _BRIDGE.writeErrorBlock("%s: %s\n" % (type(exc).__name__, exc))


def run_script(source, filename, work_dir, argv):
    global _STOP
    _STOP["v"] = False

    if work_dir and os.path.isdir(work_dir):
        try:
            os.chdir(work_dir)
        except Exception:
            pass

    script_name = os.path.basename(filename) if filename else "<script>"
    sys.argv = [script_name] + list(argv or [])
    sys.path.insert(0, os.path.dirname(os.path.abspath(filename)) if filename else work_dir)

    started = time.time()
    _BRIDGE.running(0.0)

    try:
        code = compile(source, script_name, "exec")
    except SyntaxError as exc:
        location = "%s:%s" % (script_name, exc.lineno)
        _BRIDGE.writeErrorBlock(
            "SyntaxError: %s\n  at %s\n" % (exc.msg or "", location)
        )
        _BRIDGE.finished(1, "SyntaxError", time.time() - started)
        return

    namespace = {
        "__name__": "__main__",
        "__file__": os.path.abspath(filename) if filename else script_name,
        "__builtins__": builtins,
        "__doc__": None,
        "__package__": None,
    }

    try:
        sys.settrace(_trace)
        exec(code, namespace, namespace)
        _flush_streams()
        elapsed = time.time() - started
        _BRIDGE.finished(0, "OK", elapsed)
    except KeyboardInterrupt:
        _flush_streams()
        sys.stderr.write("\n[PyStudio] stopped by user\n")
        _BRIDGE.finished(130, "interrupted", time.time() - started)
    except SystemExit as exc:
        _flush_streams()
        code = exc.code if isinstance(exc.code, int) else 0
        _BRIDGE.finished(code, "exit(%s)" % code, time.time() - started)
    except BaseException as exc:
        _flush_streams()
        _report_error(exc)
        _BRIDGE.finished(1, type(exc).__name__, time.time() - started)
    finally:
        try:
            sys.settrace(None)
        except Exception:
            pass
        _STOP["v"] = False


def _trace(frame, event, arg):
    if _STOP["v"]:
        raise KeyboardInterrupt()
    return _trace


def run_line(source, work_dir):
    """One line of the interactive console (`python` with no arguments)."""
    global _STOP
    _STOP["v"] = False
    if work_dir and os.path.isdir(work_dir):
        try:
            os.chdir(work_dir)
        except Exception:
            pass

    mode = "exec"
    stripped = source.strip()
    if stripped and not stripped.endswith(":") and "\n" not in stripped:
        try:
            compile(stripped, "<console>", "eval")
            mode = "eval"
        except SyntaxError:
            mode = "exec"

    try:
        sys.settrace(_trace)
        if mode == "eval":
            result = eval(compile(stripped, "<console>", "eval"), _REPL_GLOBALS)
            if result is not None:
                sys.stdout.write(repr(result) + "\n")
        else:
            try:
                code = compile(source, "<console>", "single")
            except SyntaxError:
                code = compile(source, "<console>", "exec")
            exec(code, _REPL_GLOBALS)
        _flush_streams()
    except KeyboardInterrupt:
        sys.stderr.write("\nKeyboardInterrupt\n")
    except SystemExit:
        sys.stdout.write("[PyStudio] console closed\n")
    except BaseException as exc:
        _flush_streams()
        _report_error(exc)
    finally:
        try:
            sys.settrace(None)
        except Exception:
            pass
        _STOP["v"] = False


def reset_repl():
    _REPL_GLOBALS.clear()
    _REPL_GLOBALS["__name__"] = "__pyconsole__"
    _REPL_GLOBALS["__doc__"] = None


# --------------------------------------------------------------------------
# a tiny runtime "pip" (pure Python wheels only)
# --------------------------------------------------------------------------
PYPI_JSON = "https://pypi.org/pypi/%s/json"


def _say(text):
    if _BRIDGE is not None:
        _BRIDGE.writeStdout(text)
    else:
        print(text, end="")


def _say_err(text):
    if _BRIDGE is not None:
        _BRIDGE.writeStderr(text)
    else:
        print(text, end="", file=sys.stderr)


def _normalize(name):
    return re.sub(r"[-_.]+", "-", name).lower()


def _parse_requirement(spec):
    """'requests>=2.0 ; python_version>="3.7"' -> ('requests', '>=2.0')"""
    body = spec.split(";")[0].strip()
    match = re.match(r"^([A-Za-z0-9][A-Za-z0-9._\-]*)\s*(.*)$", body)
    if not match:
        return None, None
    return match.group(1), (match.group(2) or "").strip()


def _read_manifest(site_dir):
    path = os.path.join(site_dir, _INSTALLED_MANIFEST)
    if os.path.exists(path):
        try:
            with open(path, "r", encoding="utf-8") as fh:
                return json.load(fh)
        except Exception:
            pass
    return {}


def _write_manifest(site_dir, manifest):
    try:
        with open(os.path.join(site_dir, _INSTALLED_MANIFEST), "w", encoding="utf-8") as fh:
            json.dump(manifest, fh, indent=2)
    except Exception:
        pass


def _pypi_json(name):
    url = PYPI_JSON % _normalize(name)
    try:
        with urllib.request.urlopen(url, timeout=20) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        if exc.code == 404:
            _say_err("ERROR: No matching distribution found for '%s'\n" % name)
        else:
            _say_err("ERROR: PyPI returned HTTP %s for %s\n" % (exc.code, name))
    except Exception as exc:
        _say_err("ERROR: cannot reach PyPI (%s)\n" % exc)
    return None


def _choose_wheel(data):
    candidates = []
    for url_info in data.get("urls", []):
        if url_info.get("packagetype") != "bdist_wheel":
            continue
        filename = url_info.get("filename", "")
        if filename.endswith("-none-any.whl") or filename.endswith("-none-any.whl.asc"):
            candidates.append(url_info)
    if not candidates:
        return None
    # prefer py3-none-any over py2.py3-none-any
    candidates.sort(key=lambda c: 0 if "py3-none-any" in c["filename"] else 1)
    return candidates[0]


def _install_wheel(wheel_url, site_dir):
    import tempfile

    tmp = tempfile.mkdtemp(dir=site_dir)
    archive = os.path.join(tmp, "wheel.whl")
    urllib.request.urlretrieve(wheel_url, archive)
    try:
        with zipfile.ZipFile(archive) as zf:
            zf.extractall(site_dir)
    finally:
        try:
            os.remove(archive)
        except Exception:
            pass
        try:
            os.rmdir(tmp)
        except Exception:
            pass


def _wheel_requires(site_dir, wheel_filename, package_name):
    """Read Requires-Dist out of the wheel we just extracted."""
    stem = wheel_filename.split("-")[0]
    dist_info = None
    try:
        for entry in os.listdir(site_dir):
            if entry.endswith(".dist-info") and entry.lower().startswith(
                _normalize(package_name) + "-"
            ):
                dist_info = os.path.join(site_dir, entry)
                break
    except Exception:
        return []
    if dist_info is None:
        return []

    # remove leftover data folders / keep the manifest tidy
    found = []
    try:
        meta = os.path.join(dist_info, "METADATA")
        if os.path.exists(meta):
            with open(meta, "r", encoding="utf-8") as fh:
                import email.parser

                message = email.parser.Parser().parsestr(fh.read())
            for raw in message.get_all("Requires-Dist") or []:
                found.append(raw)
    except Exception:
        pass
    _ = stem
    return found


def _pip_install_one(spec, site_dir, depth, seen):
    name, _version = _parse_requirement(spec)
    if name is None:
        _say_err("ERROR: invalid requirement '%s'\n" % spec)
        return False
    if _normalize(name) in seen:
        return True
    seen.add(_normalize(name))

    _say("Collecting %s\n" % spec)
    data = _pypi_json(name)
    if data is None:
        return False

    wheel = _choose_wheel(data)
    if wheel is None:
        version = data.get("info", {}).get("version", "?")
        _say_err(
            "\n'%s' (%s) has no pure-Python wheel for Android.\n" % (name, version)
        )
        _say_err(
            "Python packages with C/C++ code cannot be compiled on the phone.\n"
            "They must be bundled into the APK at build time - add the line\n"
            '    install("%s")\n' % name
        )
        _say_err(
            "inside the pip { } block of app/build.gradle.kts, then re-upload the\n"
            "project ZIP: the GitHub Action builds a new signed APK automatically.\n"
            "Pre-built Android wheels are available for numpy, scipy, matplotlib,\n"
            "opencv-python, pillow, pandas, scikit-learn, ... \n\n"
        )
        return False

    try:
        _install_wheel(wheel["url"], site_dir)
    except Exception as exc:
        _say_err("ERROR: download failed (%s)\n" % exc)
        return False

    requires = _wheel_requires(site_dir, wheel["filename"], name)
    if depth < 4:
        for req in requires:
            req_name, _rest = _parse_requirement(req)
            if req_name is None:
                continue
            marker = req.split(";")[1].strip() if ";" in req else ""
            if "extra ==" in marker or "extra==" in marker:
                continue
            _pip_install_one(req_name, site_dir, depth + 1, seen)

    manifest = _read_manifest(site_dir)
    manifest[_normalize(name)] = data.get("info", {}).get("version", "0")
    _write_manifest(site_dir, manifest)
    _say("Successfully installed %s-%s\n" % (name, manifest[_normalize(name)]))
    return True


def _pip_list(site_dir):
    manifest = _read_manifest(site_dir)
    _say("Packages bundled in the APK:\n")
    for mod in ("numpy", "scipy", "matplotlib", "cv2", "PIL"):
        try:
            module = importlib.import_module(mod)
            version = getattr(module, "__version__", "?")
            _say("  %-14s %s\n" % (mod, version))
        except Exception:
            _say("  %-14s (not available)\n" % mod)
    _say("Packages installed at runtime:\n")
    if manifest:
        for key in sorted(manifest):
            _say("  %-14s %s\n" % (key, manifest[key]))
    else:
        _say("  (none)\n")


def _pip_uninstall(name, site_dir):
    key = _normalize(name)
    manifest = _read_manifest(site_dir)
    if key not in manifest:
        _say_err("WARNING: Skipping %s as it is not installed.\n" % name)
        return
    removed = 0
    for entry in list(os.listdir(site_dir)):
        if entry.lower().startswith(key + "-") and (
            entry.endswith(".dist-info") or entry.endswith(".egg-info")
        ):
            _rmtree(os.path.join(site_dir, entry))
            removed += 1
    manifest.pop(key, None)
    _write_manifest(site_dir, manifest)
    _say("Successfully uninstalled %s\n" % name)


def _rmtree(path):
    for root, dirs, files in os.walk(path, topdown=False):
        for f in files:
            try:
                os.remove(os.path.join(root, f))
            except Exception:
                pass
        for d in dirs:
            try:
                os.rmdir(os.path.join(root, d))
            except Exception:
                pass
    try:
        os.rmdir(path)
    except Exception:
        pass


PIP_HELP = """usage: pip <command> [args]

  pip install <package>     install a pure-Python package from PyPI
  pip install pkg==1.2.3    install a specific version
  pip list                  show bundled + runtime packages
  pip uninstall <package>   remove a runtime package
  pip help                  this text

Note: libraries that contain native code (numpy, opencv, torch, ...) cannot be
compiled on the phone. They are already bundled in the APK at build time - see
app/build.gradle.kts.
"""


def pip_command(args, site_dir):
    if _SITE_DIR and not os.path.isdir(_SITE_DIR):
        os.makedirs(_SITE_DIR, exist_ok=True)
    if not args:
        _say(PIP_HELP)
        return
    command = args[0].lower()
    rest = args[1:]
    if command in ("install", "-i", "i"):
        if not rest:
            _say_err("ERROR: pip install requires at least one package name\n")
            return
        seen = set()
        ok = True
        for spec in rest:
            if spec.startswith("-"):
                continue  # options such as -U / --upgrade are ignored
            ok = _pip_install_one(spec, _SITE_DIR or site_dir, 0, seen) and ok
        if not ok:
            _say_err("\nNote: run `pip list` to see what is available.\n")
        return
    if command == "list":
        _pip_list(_SITE_DIR or site_dir)
        return
    if command == "uninstall":
        for name in rest:
            if not name.startswith("-"):
                _pip_uninstall(name, _SITE_DIR or site_dir)
        return
    if command in ("help", "--help", "-h"):
        _say(PIP_HELP)
        return
    _say_err("Unknown command: %s\n%s" % (command, PIP_HELP))
