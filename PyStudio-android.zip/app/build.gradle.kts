import java.util.Properties

// ---------------------------------------------------------------------------
// PyStudio - app module
//
// Python runtime: Chaquopy (https://chaquo.com/chaquopy)
//   * CPython is compiled for Android and bundled inside the APK.
//   * Packages with native code (numpy / opencv / matplotlib / pillow / scipy)
//     are pre-built "Android wheels" that are downloaded and packaged at BUILD
//     time, so on the phone a plain `import cv2` works with no extra setup.
//
// versionCode is injected by CI (`-Ppystudio.versionCode=<run number>`) so every
// new build installs straight over the previous one.
// ---------------------------------------------------------------------------

// ---- version -----------------------------------------------------------------
val pystudioVersionCode: Int =
    (project.findProperty("pystudio.versionCode") as String?)?.trim()?.toIntOrNull() ?: 1
val pystudioVersionName: String =
    (project.findProperty("pystudio.versionName") as String?)?.trim() ?: "1.0.0"

// ---- signing (fixed keystore shipped with the project) -----------------------
val keystoreProps = Properties()
val keystorePropsFile = rootProject.file("keystore.properties")
if (keystorePropsFile.exists()) {
    keystorePropsFile.inputStream().use { keystoreProps.load(it) }
} else {
    // Sensible defaults so a build never fails just because a file is missing.
    keystoreProps["storeFile"] = "pystudio-release.keystore"
    keystoreProps["storePassword"] = "pystudio"
    keystoreProps["keyAlias"] = "pystudio"
    keystoreProps["keyPassword"] = "pystudio"
    keystoreProps["storeType"] = "PKCS12"
}

// Optional: CI can tell Chaquopy exactly which interpreter to use.
val buildPythonPath: String = System.getenv("PYSTUDIO_BUILD_PYTHON") ?: ""

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("com.chaquo.python")
}

android {
    namespace = "com.pystudio.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.pystudio.app"
        minSdk = 24
        targetSdk = 34

        // NOTE: never change applicationId - it is what allows updates to be
        // installed over the previous version without uninstalling.
        versionCode = pystudioVersionCode
        versionName = pystudioVersionName

        // arm64-v8a  -> every modern Android phone
        // x86_64     -> emulator / Chromebook. Remove it for a ~40% smaller APK.
        ndk {
            abiFilters += listOf("arm64-v8a", "x86_64")
        }
    }

    signingConfigs {
        create("release") {
            storeFile = file(keystoreProps.getProperty("storeFile", "pystudio-release.keystore"))
            storePassword = keystoreProps.getProperty("storePassword", "pystudio")
            keyAlias = keystoreProps.getProperty("keyAlias", "pystudio")
            keyPassword = keystoreProps.getProperty("keyPassword", "pystudio")
            storeType = keystoreProps.getProperty("storeType", "PKCS12")
        }
    }

    buildTypes {
        debug {
            // Signed with the release key as well, so debug <-> release replace
            // each other without uninstalling.
            signingConfig = signingConfigs.getByName("release")
        }
        release {
            isMinifyEnabled = false
            isShrinkResources = false
            signingConfig = signingConfigs.getByName("release")
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }

    packaging {
        resources {
            excludes += setOf(
                "META-INF/LICENSE*",
                "META-INF/NOTICE*",
                "META-INF/DEPENDENCIES",
                "META-INF/versions/**"
            )
        }
        jniLibs {
            keepDebugSymbols += "**/*.so"
        }
    }
}

// ---------------------------------------------------------------------------
// Chaquopy configuration (top level block, not inside `android`).
// ---------------------------------------------------------------------------
chaquopy {
    defaultConfig {
        // Runtime Python version (3.10 - 3.14 for Chaquopy 17.x).
        version = "3.11"

        if (buildPythonPath.isNotBlank()) {
            buildPython(buildPythonPath)
        }

        pip {
            // ---- bundled into the APK at BUILD time --------------------------
            // After this, a plain `import numpy` / `import cv2` on the phone
            // works with zero extra setup.
            install("numpy")
            install("matplotlib")
            install("pillow")
            install("opencv-python")
            install("scipy")
            // Add more libraries here (for example install("pandas")) and rebuild.
        }
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")
    implementation("androidx.annotation:annotation:1.8.2")
    implementation("org.jetbrains.kotlin:kotlin-stdlib:2.0.21")
}
