# PyStudio ProGuard / R8 rules.
# Minification is disabled for the release build (Python native libs + reflection),
# so these rules are only a safety net if someone enables minifyEnabled.

# Keep Chaquopy runtime classes (heavily reflection based).
-keep class com.chaquo.python.** { *; }
-dontwarn com.chaquo.python.**

# Keep the bridge object that Python calls back into.
-keep class com.pystudio.app.OutputBridge { *; }

# Keep sora-editor / our own views referenced from XML layouts.
-keep class com.pystudio.app.** extends android.view.View { *; }

# Matplotlib / numpy / opencv are pure data - nothing to keep, just silence noise.
-dontwarn java.awt.**
-dontwarn javax.swing.**
-dontwarn org.slf4j.**
