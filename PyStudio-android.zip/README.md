# PyStudio - Python IDE for Android

A complete Python editor + compiler that runs **entirely on the phone**.
The interpreter is real CPython (provided by [Chaquopy](https://chaquo.com/chaquopy)),
so NumPy, SciPy, Matplotlib, Pillow and OpenCV all work with a plain `import`.

```
app/
 ├─ build.gradle.kts                 Chaquopy config + bundled pip packages + signing
 ├─ pystudio-release.keystore        fixed signing key (same key on every build)
 ├─ src/main/AndroidManifest.xml
 ├─ src/main/java/com/pystudio/app/
 │    ├─ PyStudioApp.kt              starts the interpreter
 │    ├─ MainActivity.kt             editor / output / terminal + file dialogs
 │    ├─ PythonEngine.kt             Kotlin <-> Python bridge
 │    ├─ OutputBridge.kt             callbacks that Python calls into
 │    ├─ OutputBus.kt                UI event bus
 │    ├─ PythonHighlighter.kt        syntax highlighting
 │    ├─ LineNumberView.kt           line-number gutter
 │    ├─ OutputAdapter.kt            output tab (text / errors / images)
 │    ├─ TerminalAdapter.kt          terminal + file list adapters
 │    ├─ FileManager.kt              phone storage, sample scripts
 ├─ src/main/python/pystudio_runner.py   stdout redirect, cv2/plt/PIL patching, pip
 └─ src/main/res/                    Material 3 dark theme, RTL aware
```

## Features

* **Editor** - line numbers, Python syntax highlighting, auto indent, undo/redo,
  run & stop buttons, save/open/new files, search-free simple UI in Persian (RTL).
* **Output tab** - stdout, coloured tracebacks and *rendered images*
  (`plt.show()`, `cv2.imshow()`, `PIL.Image.show()` all become pictures), plus a
  prompt for `input()`.
* **Terminal tab** - `ls`, `cd`, `pwd`, `cat`, `python`, `python -c`,
  `python main.py`, `pip install/list/uninstall`, `clear`, `help`; anything else
  is executed by the real Android shell (toybox).
* **File access** - press *درج مسیر فایل* while the caret is inside a function
  call such as `cv2.imread( ... )` and the picked file path is inserted between
  the parentheses. Works for every file type.
* **Project folder** - `/storage/emulated/0/PyStudio` (falls back to the
  app-specific folder if "All files access" is not granted).

## Adding a library

* **Pure Python** (requests, beautifulsoup4, sympy, ...) - just type in the
  terminal: `pip install requests`. It downloads the wheel from PyPI at runtime.
* **Native code** (pandas, torch, scikit-learn, ...) - cannot be compiled on the
  phone. Add it to `app/build.gradle.kts`:

  ```kotlin
  chaquopy {
      defaultConfig {
          pip {
              install("pandas")
          }
      }
  }
  ```

  then re-upload the project ZIP: the GitHub Action builds a new signed APK that
  installs over the old one.

## Signing / updates

`keystore.properties` + `app/pystudio-release.keystore` are part of the project.
`versionCode` comes from the CI run number, `applicationId` never changes, so
every new release installs directly over the previous one.

## Known Android limitations (honest list)

* `cv2.imshow` cannot open a native window on Android - PyStudio renders it as a
  picture in the Output tab (same for `plt.show()`).
* `sys.settrace` based Stop: a long single C call (a big numpy operation) is only
  interrupted once it returns.
* No `multiprocessing`/`os.fork` (Chaquopy), `torch`/`tensorflow` wheels are very
  large and not pre-built for every Python version.
* `pip install` at runtime works for pure-Python packages only.
